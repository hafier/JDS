package devsjava.modelisation.model;

import java.util.*;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;

/**
 * Title: Kit devel DEVS Description: kit DEVS Copyright: Copyright (c) 2000
 * Company:Universite de corse
 *
 * @author jbfilippi
 * @version 1.0
 */
public abstract   class AtomicModel extends devsjava.modelisation.Model {

    public static final int PASSIVE = 0;
    public static final int BUSY = 1;

    int phase;
    protected ModelProperties states = new ModelProperties();

    public AtomicModel(String child) {
        this.setChild(child);
    }

    public void declare(String name, CoupledModel c) {
        this.setParent(c);
        this.setName(name);
        Simulator nv = new Simulator(this, c.getProcess());
        this.initProcess(nv);
        phase = PASSIVE;
    }

    public AtomicModel(String name, String child, CoupledModel c) {
        super(child, c);
        this.setName(name);
        Simulator nv = new Simulator(this, c.getProcess());
        this.initProcess(nv);
        phase = PASSIVE;
    }

    public int getPhase() {
        return phase;
    }

    public void setPhase(int e) {
        phase = e;
    }

    ;
    public abstract EventVector extTransition(Message m);

    public abstract EventVector outFunction(Message m);

    public abstract void intTransition();

    public int advanceTime() {
        return Integer.MAX_VALUE;
    }

    public ModelProperties getStates() {
        return states;
    }
}
