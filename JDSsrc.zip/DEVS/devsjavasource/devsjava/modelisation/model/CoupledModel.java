package devsjava.modelisation.model;

import java.util.Vector;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;

/**
 * Title: Kit devel DEVS Description: kit DEVS Copyright: Copyright (c) 2000
 * Company:Universite de corse
 *
 * @author jbfilippi
 * @version 1.0
 */
public class CoupledModel extends devsjava.modelisation.Model {

    private Vector children = new Vector();

    private Coupling extern_input;
    private Coupling extern_output;
    private Coupling internal;

    public CoupledModel(String name, Model c) {
        declare(name, c);
    }

    public CoupledModel() {
    }

    public void declare(String name, Model c) {
        this.setChild("mc");
        this.setParent(c);
        this.setName(name);
        Processor pt = null;
        if (c != null) {
            pt = c.getProcess();
        }
        Coordinator nv_co = new Coordinator(this, pt);
        initProcess(nv_co);
        
        extern_input = new Coupling();
        extern_output = new Coupling();
        internal = new Coupling();
        
        if (c != null && c.getChild().compareTo("mc") == 0) {
            ((CoupledModel) c).addComposition(this);
        }
    }

    public void initComposition(Vector args) {
        /**
         * Initialise les sous modeles
         *//*
         ProcessorVector temp = ((Coordinator)this.getProcess()).getChildren() ;

         children.addAll(args);

         for (int i = 0; i < children.size() ;i++){
         temp.add(((Model)children.elementAt(i) ).getProcess() );
         }
         */

        for (int i = 0; i < args.size(); i++) {
            addComposition((Model) args.elementAt(i));
        }
    }

    public void addComposition(Model arg) {
        /**
         * Initialise les sous modeles un a un
         */
        ProcessorVector temp = ((Coordinator) this.getProcess()).getChildren();
        children.add(arg);
        temp.add(((Model) children.lastElement()).getProcess());

        // ((Coordinator)this.getProcess()).getChildren().add(arg.getProcess());
    }

    public void addCoupling(String s, Port src, Port dest) {
        /**
         * Initialise les liens
         */
        if (s.compareTo("IN") == 0) {
            extern_input.assign(extern_input.getLg(), src, dest);
        }
        if (s.compareTo("OUT") == 0) {
            extern_output.assign(extern_output.getLg(), src, dest);
        }
        if (s.compareTo("INT") == 0) {
            internal.assign(internal.getLg(), src, dest);
        }
         System.out.println(this + " Couplage " + s + " de " + src.getName() + " avec " + dest.getName() );

    }

    public Model father() {
        return this.father();
    }

    public void getReceiver(Message m) {
        /**
         * determine quels sous composants recevront une entree d'un evenement
         * exterieur du parent
         */
        Port port_dest;
        port_dest = findPort(extern_input, m.getPort());

        m.setSource(port_dest.getOwner().getProcess());
        m.setPort(port_dest);
    }

    public void getInfluencee(Message m) {
        /**
         * determine les ports dont le message vas etre dirigee en sortie
         */
        Port port_dest;
        port_dest = findPort(extern_output, m.getPort());   // teste si le port fais partie des ports external
        if (port_dest != null) {
            m.setSource(getProcess());    // sinon il l'affecte au processeur des modeles internal
        } else {
            port_dest = findPort(internal, m.getPort());
            m.setSource(port_dest.getOwner().getProcess());
        }

        m.setPort(port_dest); // et il update l'adresse au message
    }

    public Vector getChildren() {
        /**
         * revoie les enfants du modele (vecteur)
         */
        return children;
    }

    public Port findPort(Coupling c, Port p) {
        /**
         * renvoie le port de dest a partir du port d'entree
         */

        return c.findPort(p);
    }

    public Coupling getIn() {
        return extern_input;
    }

    public Coupling getOut() {
        return extern_output;
    }

    public Coupling getInt() {
        return internal;
    }

    public void setIn(Coupling extern_input) {
        this.extern_input = extern_input;
    }

    public void setOut(Coupling extern_output) {
        this.extern_output = extern_output;
    }

    public void setInt(Coupling internal) {
        this.internal = internal;
    }

}
