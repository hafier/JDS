package devsjava.modelisation;

import java.util.Properties;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class ModelProperties extends Properties {

  public ModelProperties() {
  super();
  }

  public int getInt(String key){
      return Integer.parseInt(this.getProperty(key));
  }
  public double getDouble(String key){
      return Double.parseDouble(this.getProperty(key));
  }
  public String getString(String key){
      return this.getProperty(key);
  }

  public void setInt(String key, int value){
      this.setProperty(key, Integer.toString(value)) ;
  }


  public void setDouble(String key, double value){
      this.setProperty(key, Double.toString(value)) ;
  }


  public void setString(String key, String value){
      this.setProperty(key, value);
  }





}

