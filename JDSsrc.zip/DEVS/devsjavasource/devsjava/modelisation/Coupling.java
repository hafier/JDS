package devsjava.modelisation;

import java.util.Vector;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;
import devsjava.*;

/**
 * Title: Kit devel DEVS Description: kit DEVS Copyright: Copyright (c) 2000
 * Company:Universite de corse
 *
 * @author jbfilippi
 * @version 1.0
 */

public class Coupling {

    private Vector source;
    private Vector destination;

    public Coupling() {
        source = new Vector();
        destination = new Vector();
    }

    public void initCoupling() {
        source = new Vector();
        destination = new Vector();
    }

    public void assign(int i, Port src, Port dest) {
        source.insertElementAt(src, i);
        destination.insertElementAt(dest, i);
    }

    public int getLg() {
        /**
         * renvoie le nombre de liens total
         */
        return source.size();
    }

    public Port getName(String s, int i) {
        /**
         * renvoie le port a l'index i
         */
        if (s.compareTo("SOURCE") == 0) {
            return ((Port) source.elementAt(i));
        }
        if (s.compareTo("DESTINATION") == 0) {
            return ((Port) destination.elementAt(i));
        }
        return null;
    }

    public Port findPort(Port p) {
        /**
         * renvoie le port de sortie correspondant au port d'entree
         */
        if (source.lastIndexOf(p) > -1) {
            return (Port) destination.elementAt(source.lastIndexOf(p));
        } else {
            return null;
        }
    }

    public String getName(Port s, int i) {
        /**
         * renvoie le nom du port a l'index i
         */
        if (s.compareTo("SOURCE") == 0) {
            return ((Port) source.elementAt(i)).getName();
        };
        if (s.compareTo("DESTINATION") == 0) {
            return ((Port) destination.elementAt(i)).getName();
        };
        return null;
    }

    public String toString() {
        String a = new String();
        for (int i = 0; i < source.size(); i++) {
            a += "[" + source.elementAt(i) + "->" + destination.elementAt(i) + "]";
        }
        return a;
    }

    public Vector getSrc() {
        return source;
    }

    public Vector getDest() {
        return destination;
    }
}
