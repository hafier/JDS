package devsjava.modelisation;
import java.util.Vector;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;
import devsjava.*;
/**
 * Title: Kit devel DEVS
 * Description: kit DEVS
 * Copyright:    Copyright (c) 2000
 * Company:Universite de corse
 * @author jbfilippi
 * @version 1.0
 */

public class Port implements java.lang.Comparable {

    private String		name;
    private Model owner;
    public Port(Model m, String name){
    this.name = name;
    owner = m;
    }
    public Port(Model m, String name, String place){
    this.name = name;
    owner = m;
    m.initPort(place,this);
    }
    public Port(){}
    public void declare(Model m, String name, String place){
    this.name = name;
    owner = m;
    m.initPort(place,this);
    }



    public String	getName()   {return owner.getName() + "." + this.name;}
    public String	toString()   {return this.name;}
    public void	setName(String name)   {this.name = name;}
    public Model getOwner()   {return this.owner;}
    public int compareTo(Object p){
    Port tp = (Port)p;
    if (tp == this)  return 0;
    else return -1;
  //  return getName().compareTo(tp);
    }
}