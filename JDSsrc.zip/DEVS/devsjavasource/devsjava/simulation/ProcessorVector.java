package devsjava.simulation;
import java.util.Vector;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;
import devsjava.*;

/**
 * Title: Kit devel DEVS
 * Description: kit DEVS
 * Copyright:    Copyright (c) 2000
 * Company:Universite de corse
 * @author jbfilippi
 * @version 1.0
 */

public class ProcessorVector extends Vector {

  public ProcessorVector() {}
  public ProcessorVector(Model m, String ch, Processor p){}

}