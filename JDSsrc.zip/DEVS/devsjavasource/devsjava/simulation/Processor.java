package devsjava.simulation;

import java.util.Vector;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;
import devsjava.*;

/**
 * Title: Kit devel DEVS Description: kit DEVS Copyright: Copyright (c) 2000
 * Company:Universite de corse
 *
 * @author jbfilippi
 * @version 1.0
 */
public class Processor extends devsjava.Entity {

    private Processor parent;
    private Model composant_devs;
    private String child;
    private int tnext;
    private int tlast;

    public Processor() {
    }

    public Processor(Model m, String ch, Processor p) {
        this.composant_devs = m;
        this.child = ch;
        this.parent = p;
        if (m != null) {
            this.setName(m.getName() + ".processor");
        } else {
            this.setName("root processor");
        }
        this.tlast = 0;
        this.tnext = 0;

    }

    public void initParent(Processor p) {
        parent = p;
    }

    public Processor getParent() {
        return parent;
    }

    public Model getModel() {
        return composant_devs;
    }

    public String getChild() {
        return child;
    }

    public int getTnext() {
        return tnext;
    }

    public int getTlast() {
        return tlast;
    }

    public void setTnext(int tn) {
        tnext = tn;
    }

    public void setTlast(int tl) {
        tlast = tl;
    }

    public String toString() {
        return child + "." + this.getModel();
    }
}
