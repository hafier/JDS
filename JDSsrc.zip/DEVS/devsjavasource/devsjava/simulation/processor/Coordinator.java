package devsjava.simulation.processor;

import java.util.Vector;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;
import devsjava.*;

/**
 * Title: Kit devel DEVS Description: kit DEVS Copyright: Copyright (c) 2000
 * Company:Universite de corse
 *
 * @author jbfilippi
 * @version 1.0bgfdhgfdhgf
 */

public class Coordinator extends devsjava.simulation.Processor {

    private ProcessorVector children = new ProcessorVector();
    private MessageVector ECH = new MessageVector();
    private MessageVector EV = new MessageVector();

    ;

  public Coordinator() {
    }

    public Coordinator(Model m, Processor p) {
        super(m, "coordinateur", p);

    }

    public void insert(String s, Message m) {

        if (m.getType().compareTo("*") == 0) {
        }
        if (m.getType().compareTo("done") == 0) {
            m.setType("*");
        }
        if (m.getType().compareTo("x") == 0) {
            if ((m.getPort() != null) && (m.getPort().getOwner().equals(this.getModel()))) {
                ((CoupledModel) this.getModel()).getReceiver(m);
            }
        }
        if (m.getType().compareTo("y") == 0) {
            ((CoupledModel) this.getModel()).getInfluencee(m);
            if (m.getSource() != this) {
                m.setType("x");
            }
        }

        if (s.compareTo("EV") == 0) {
            EV.insertEV(m, ((CoupledModel) this.getModel()).getChildren());
        } else {
            ECH.insertECH(m);
        }

    }

    public void receivers(Message m) {

        MessageVector msg_lst;
        Message mess;

        if (this.getParent().getChild().compareTo("root") == 0) {
            while ((this.getTnext() < ECH.firstTime()) && EV.isNull()) {
                time = this.getTnext();
                //  if ( m!= null)System.out.println(m + " " + this.influences(this.getTnext()) );
                Processor p = null;
                try {
                    p = this.influences(this.getTnext());
                    ((Coordinator) p).receivers(m);
                } catch (Exception ex) {
                    System.out.println("Message null sur " + p);
                    time = ECH.firstTime();
                    m = null;
                    break;
                }
                this.setTn();
            }
            if (EV.isNull()) {
                time = ECH.firstTime();
            }
            m = null;
        } //a remettre
        else if (m.getType().compareTo("*") == 0) {
            if (m.getSource() != null) {
                this.insert("EV", m);
            }
        } else {
            this.insert("ECH", m);
        }
        //   else  if (m.getType().compareTo("*") == 0)  this.insert("EV",m);
        m = null;


        /*
         while ((ECH.size() > 0) && (ECH.firstTime() == time))
         {  Message temp = (Message)ECH.remove(0) ;

         insert("EV", temp);
         }*/
        EV.translate(ECH, time, this.priorityList());

        if (EV.isNull()) {
            ((Coordinator) this.influences(this.getTnext())).receivers(m);
            this.setTn();
        } else {
            while (!EV.isNull()) {
                mess = EV.takeFirst();
                if (mess.getSource().getChild().compareTo("simulator") == 0) {
                    msg_lst = ((Simulator) mess.getSource()).receivers(mess);
                    for (; msg_lst.size() > 0;) {
                        mess = msg_lst.takeFirst();

                        if (mess.getTime() == time) {
                            insert("EV", mess);
                        } else {
                            insert("ECH", mess);
                        }
                    }
                } else {
                    if (mess.getSource().equals(this)) {
                        if (this.getParent().getChild().compareTo("root") == 0) {
                            ((Root) this.getParent()).receivers(mess);
                        } else {
                            ((Coordinator) this.getParent()).insert("EV", mess);
                        }
                    } else {
                        ((Coordinator) mess.getSource()).receivers(mess);
                    }
                }
            }
            this.setTn();
        }

    }

    public Processor influences(int tmin) {
        int i, indexTime = -1;

        for (i = 0; indexTime == -1; i++) {
            if (tmin == ((Processor) children.elementAt(i)).getTnext()) {
                indexTime = i;
            }
        }
        return (Processor) children.elementAt(indexTime);
    }

    public void setTn() {
        int tmin = Integer.MAX_VALUE;

        if (EV.isNull()) {
            for (int i = 0; i < children.size(); i++) {
                if (tmin > ((Processor) children.elementAt(i)).getTnext()) {
                    tmin = ((Processor) children.elementAt(i)).getTnext();
                }
            }
            if (tmin < ECH.firstTime()) {
                this.setTnext(tmin);
            } else {
                this.setTnext(ECH.firstTime());
            }
        } else {
            this.setTnext(EV.firstTime());
        }
    }

    public ProcessorVector getChildren() {
        return children;
    }

    public Vector priorityList() {
        return ((CoupledModel) getModel()).getChildren();
    }

    public MessageVector getEV() {
        return EV;
    }

    public MessageVector getECH() {
        return ECH;
    }

}
