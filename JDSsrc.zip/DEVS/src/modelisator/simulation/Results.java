/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelisator.simulation;

import modelisator.utils.CopyPastPopupMenu;
import java.io.OutputStream;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 *
 * @author KACHER
 */
public class Results extends OutputStream {

    JScrollPane jScrollPane1;
    int count;
    JTextArea jTextArea1;

    public JScrollPane getPane() {
        return jScrollPane1;
    }

    public JTextArea getResults() {
        return jTextArea1;
    }
    String line;

    public Results() {
        this.jScrollPane1 = new JScrollPane();
        this.line = new String();
        this.jTextArea1 = new JTextArea();
        this.jTextArea1.setText("");
        new CopyPastPopupMenu(this.jTextArea1);
        this.jScrollPane1.getViewport().add(this.jTextArea1, null);
        this.jScrollPane1.setAutoscrolls(true);
    }

    public void write(final int i) {
        final char[] temp = {(char) i};
        this.jTextArea1.append(new String(temp));
        if (this.count == 4) {
            this.count = 0;
        } else {
            ++this.count;
        }
        this.jScrollPane1.getVerticalScrollBar().setValue(this.jTextArea1.getHeight());
        this.jScrollPane1.getParent().repaint();
    }

}
