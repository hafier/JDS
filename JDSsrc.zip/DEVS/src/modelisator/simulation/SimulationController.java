package modelisator.simulation;

import modelisator.EditorWindow;
import javax.swing.*;
import devsjava.simulation.processor.*;

public class SimulationController implements Runnable {

    int speed = 500;
    Thread t = null;
    Root r;
    long counttime;
    boolean repaintOrNot;
    EditorWindow jc = null;

    public SimulationController(Root r) {
        this.r = r;

    }
    JProgressBar jProgressBar1;

    public void run() {
        try {
            while (t != null) {
                r.simulate();

                repaintComponent();
                if (r.getState() == Root.SIMULATION_ENDED) {
                    stop();
                }
                this.jProgressBar1.setValue(jProgressBar1.getValue() + 1);
                Thread.sleep(speed);
                ((SimulationWindow) SwingUtilities.getWindowAncestor(this.jProgressBar1)).jLabel2.setText("Simulation Time : " + (System.currentTimeMillis() - counttime) + " ms");

            }
        } catch (InterruptedException e) {
            return;
        }
    }

    public void start(JProgressBar jProgressBar1) {
        this.jProgressBar1 = jProgressBar1;
        if (t != null) {
            t.start();
        } else {
            t = new Thread(this);
            counttime = System.currentTimeMillis();
            t.start();
        }
    }

    public void stop() {
        if (jc != null) {
            t = null;
        }
    }

    public void repaintComponent() {
        if (jc != null) {
            jc.d.repaint();
        }
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public void setRepaintPolicy(boolean repaintOrNot) {
        this.repaintOrNot = repaintOrNot;
    }

    public void setComponent(EditorWindow jc) {
        this.jc = jc;
    }
}
