/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelisator;

import modelisator.utils.xmlLoader;
import modelisator.modelisation.CoupledModelComponent;
import modelisator.EditorWindow;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

/**
 *
 * @author KACHER
 */
public class Project {

    //static String enginesrc = "";
    public static String projectpath = "";
    xmlLoader doc;
    public static String ProjectName;

    public xmlLoader loadProject() {
        doc = null;
        JFileChooser jfc1 = new JFileChooser();
        jfc1.showOpenDialog(null);
        File f = jfc1.getSelectedFile();
        f.getPath();
        if (f != null) {
            if (FilenameUtils.isExtension(f.getName(), "xml")) {

                Project.projectpath = f.getParentFile().getAbsolutePath();
                //enginesrc = "";
//        getSrc(Project.projectpath + File.separator + "SRC");
                this.doc = new xmlLoader(f.getAbsolutePath());
            } else {
                JOptionPane.showMessageDialog(null, "The selected file is not a valid XML file! Try again","Error!",JOptionPane.ERROR_MESSAGE);
            }
        }

        return this.doc;
    }

    public static boolean newProjet() {
        boolean ok = true;
        projectpath = "";
        //enginesrc = "";
        JFileChooser jfc1 = new JFileChooser();
        jfc1.showSaveDialog(null);
        File f = jfc1.getSelectedFile();
        if (f != null) {
            ProjectName = f.getName();
            Project.projectpath = f.getParentFile().getAbsolutePath() + File.separator + ProjectName;
            for (int i = 0; i < Project.projectpath.length(); i++) {
                if (Project.projectpath.charAt(i) == ' ') {
                    ok = false;
                    JOptionPane.showMessageDialog(null, "Invalide path (No Spaces) Try again","Error!",JOptionPane.ERROR_MESSAGE);
                    break;
                }
            }
            if (ok) {

                new File(Project.projectpath).mkdir();
                new File(Project.projectpath + File.separator + "ATOMICS").mkdir();
                new File(Project.projectpath + File.separator + "DATA").mkdir();
                new File(Project.projectpath + File.separator + "SRC").mkdir();
                new File(Project.projectpath + File.separator + "SRC" + File.separator + "lib");

                File srcDir = new File("devsjava");
                File destDir = new File(Project.projectpath + File.separator + "SRC" + File.separator + "lib");
                try {
                    FileUtils.copyDirectory(srcDir, destDir);
                    //getSrc(Project.projectpath + File.separator + "SRC" +File.separator+"lib");
                } catch (IOException ex) {
                    ok = false;
                    Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        } else {
            ok = false;
        }
        return ok;
    }

    public static boolean SaveProject(CoupledModelComponent root) {
        boolean ok = true;

        File fi = new File(Project.projectpath + File.separator + Project.ProjectName + ".xml");
        try {
            root.getNode().getDocument().write(new FileWriter(fi), "UTF-8");
        } catch (Exception e) {
            ok = false;
            System.err.println(e);
        }

        return ok;
    }

    public static void PrintProject(BufferedImage im) {
        boolean ok = true;

        try {
            JFileChooser jfc1 = new JFileChooser();
            jfc1.showSaveDialog(null);

            File f = jfc1.getSelectedFile();

            if (f != null) {
                String s = f.getParentFile().getAbsolutePath();
                String name = f.getName();
                for (int i = 0; i < s.length(); i++) {
                    if (s.charAt(i) == ' ') {
                        ok = false;
                        JOptionPane.showMessageDialog(null, "Invalide path (No Spaces) Try again","Error!",JOptionPane.ERROR_MESSAGE);
                        break;
                    }
                }
                if (ok) {

                    File fi = new File(s + File.separator + name + ".png");
                    try {
                        ImageIO.write(im, "PNG", fi);
                        JOptionPane.showMessageDialog(null, "Save OK");
                    } catch (IOException ex) {
                        Logger.getLogger(EditorWindow.class.getName()).log(Level.SEVERE, null, ex);
                        //this.c.ShowMsg(ex.getMessage());
                    }

                }

            } 

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void SaveResults(String res) {
        boolean ok = true;

        try {
            JFileChooser jfc1 = new JFileChooser();
            jfc1.showSaveDialog(null);
            File f = jfc1.getSelectedFile();
            if (f != null) {
                String s = f.getParentFile().getAbsolutePath();
                String name = f.getName();
                for (int i = 0; i < s.length(); i++) {
                    if (s.charAt(i) == ' ') {
                        ok = false;
                        JOptionPane.showMessageDialog(null, "Invalide path (No Spaces) Try again","Error!",JOptionPane.ERROR_MESSAGE);
                        break;
                    }
                }
                if (ok) {

                    File fi = new File(s + File.separator + name + ".txt");

                    try {
                        BufferedWriter out = new BufferedWriter(new FileWriter(fi));
                        out.write(res);
                        out.close();
                    } catch (Exception e) {
                        System.err.println("Error: " + e.getMessage());
                    }

                }

            } 

        } catch (Exception e) {
            System.out.println(e);
        }
    }

}
