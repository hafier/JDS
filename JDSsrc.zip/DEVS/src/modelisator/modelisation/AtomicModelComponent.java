/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelisator.modelisation;

import modelisator.EditorWindow;
import modelisator.utils.Editor.CodeEditor;
import modelisator.utils.AtomicClassLoader;
import modelisator.Project;
import modelisator.data.AtomicModelNode;
import modelisator.data.ModelNode;
import com.sun.xml.tree.ElementNode;
import com.sun.xml.tree.XmlDocument;
import devsjava.modelisation.Model;
import devsjava.modelisation.Port;
import devsjava.modelisation.message.Message;
import devsjava.modelisation.model.AtomicModel;
import devsjava.modelisation.model.CoupledModel;
import devsjava.simulation.EventVector;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

/**
 *
 * @author KACHER
 */
public class AtomicModelComponent extends ModelComponent {

    public AtomicModel am;
    File src = null;
    static String lib = "";

    public AtomicModelComponent(String name, Model parent, Point location, Dimension size) {
        super.model = new AtomicModel("Atomic") {
            @Override
            public EventVector extTransition(Message m) {
                return new EventVector();
            }

            @Override
            public EventVector outFunction(Message m) {
                return new EventVector();
            }

            @Override
            public void intTransition() {
            }
        };

        this.am = (AtomicModel) super.model;
        this.am.declare(name, (CoupledModel) parent);
        this.setBounds(location.x, location.y, size.width, size.height);
        this.setBackground(new Color(146, 226, 147));
//        this.setBackground(new Color(204, 204, 255));
        
    }

    public void generateJavaCode() {
        String s = "";
        try {
            src = new File(Project.projectpath + File.separator + "SRC" + File.separator + this.am.getName() + ".java");
            BufferedWriter bf = new BufferedWriter(new FileWriter(src));
            s += this.getHeader(this.am.getName());
            s += this.getConstructors(this.am.getName());
            s += this.getFooter();
            bf.write(s, 0, s.length());
            bf.close();
            EditorWindow.c.ShowMsg("Code Generated for "+this.am.getName()+" model ---> Done");
            new CodeEditor(src);
        } catch (Exception e) {
            EditorWindow.c.ShowMsg(e.getMessage());
            System.err.println(e);
        }
        this.compile();
    }

    public String getHeader(String className) {
        String s = "";
        s += "\nimport java.util.Vector;\n";
        s += "\nimport devsjava.modelisation.model.*;";
        s += "\nimport devsjava.simulation.*;";
        s += "\nimport devsjava.simulation.processor.*;";
        s += "\nimport devsjava.modelisation.*;";
        s += "\nimport devsjava.modelisation.message.*;";
        s += "\nimport devsjava.modelisation.model.*;";
        s += "\nimport devsjava.*;";
        s += "\nimport devsjava.simulation.EventVector;";
        s += "\nimport devsjava.modelisation.model.*;";
        s += "\n\npublic class " + className + " extends AtomicModel {\n";
        s += "\n";
        s += this.getPorts();
        s += "\n\n\n";
        return s;
    }

    public String getPorts() {
        String s = "";
        s += "\n // INPUT Ports";
        for (int i = 0; i < this.getModel().getInputs().size(); ++i) {
            s += "\n  Port " + this.getModel().getInputs().elementAt(i) + " = new Port(this,\"" + this.getModel().getInputs().elementAt(i) + "\",\"IN\"); ";
        }
        s += "\n // OUTPUT Ports";
        for (int i = 0; i < this.getModel().getOutputs().size(); ++i) {
            s += "\n  Port " + this.getModel().getOutputs().elementAt(i) + " = new Port(this,\"" + this.getModel().getOutputs().elementAt(i) + "\",\"OUT\"); ";
        }
        return s;
    }

    public String getConstructors(String className) {
        String s = "";
        s += "\npublic " + className + "() {";
        s += "\n      super(\"" + className + "\");";
        s += this.getPropertieString();
        s += "\n}";
        return s;
    }

    public String getPropertieString() {
        String s = "";
        s += "\n // Properties";
        for (int i = 0; i < am.getStates().size(); ++i) {
            s += "\n  states.setProperty(\"" + ((am.getStates()).keySet().toArray()[i]) + "\",\"" + ((am.getStates()).values().toArray()[i]) + "\");";
        }
        return s;
    }

    public String getFooter() {
        String s = "";
        s += "\n     public EventVector outFunction(Message m) {";
        s += "\n        // TODO add your outFunction code here: ";
        s += "\n        return new EventVector();";
        s += "\n     }";
        s += "\n      ";
        s += "\n     public void intTransition() {";
        s += "\n       // TODO add your intTransition code here:";
        s += "\n     }";
        s += "\n     ";
        s += "\n     public EventVector extTransition(Message m) {";
        s += "\n       // TODO add your extTransition code here:";
        s += "\n       return new EventVector();";
        s += "\n     }";
        s += "\n }";
        return s;
    }

    public void compile() {
        CoupledModel m = (CoupledModel) model.getParent();
        int myelem = m.getChildren().indexOf(am); 

        try {
          
             String srcfile = Project.projectpath + File.separator + "SRC" + File.separator + this.am.getName() + ".java";
             String commande = "javac -cp " +this.getLibPath()+" "+ srcfile;
            Process p = Runtime.getRuntime().exec(commande);
            BufferedReader se = new BufferedReader(new InputStreamReader(p.getErrorStream()));
            String buf, s = "";
            while ((buf = se.readLine()) != null) {
                s += " > " + buf + "\n";
            }
            EditorWindow.c.ShowMsg(s);
            if (p.waitFor() == 0) {
                EditorWindow.c.ShowMsg("Compilation for "+this.am.getName()+" model ---> Done");
                try {
                    FileUtils.copyFile(FileUtils.getFile(Project.projectpath + File.separator + "SRC" + File.separator + this.am.getName() + ".class"),
                            FileUtils.getFile(Project.projectpath + File.separator + "ATOMICS" + File.separator + this.am.getName() + ".class"));
                } catch (IOException ex) {
                    EditorWindow.c.ShowMsg(ex.getMessage());
                }
            } 
        } catch (IOException ex) {
            EditorWindow.c.ShowMsg(ex.getMessage());
        } catch (InterruptedException ex) {
            EditorWindow.c.ShowMsg(ex.getMessage());
        }
        String modelName = getModel().getName(); 
          this.model = new AtomicClassLoader().getAtomic(this.model.getName()); 
         System.out.println(model);
        am = (AtomicModel) model; 
        am.declare(modelName, m); 
        m.getChildren().setElementAt(am, myelem); 
        this.Repaint();
    }

    public void setCoupling(int x, int y) {
        if (super.fromPort != null) {

            ModelComponent m = (ModelComponent) this.getParent();
            ModelComponent mu = m.locateComponent(x + (int) this.getLocation().getX(), y + (int) this.getLocation().getY());
            if (mu == null) {
                super.toPort = m.findPort(x + (int) this.getLocation().getX(), y + (int) this.getLocation().getY());
                if (super.toPort != null) {
                    ((CoupledModel) m.getModel()).addCoupling("OUT", super.fromPort, super.toPort);
                }
            } else if (mu != this) {
                super.toPort = mu.findPort(x + (int) (this.getLocation().getX() - mu.getLocation().getX()), y + (int) (this.getLocation().getY() - mu.getLocation().getY()));
                if (super.toPort != null) {
                    ((CoupledModel) m.getModel()).addCoupling("INT", super.fromPort, super.toPort);
                }
            }
        }
    }
 
    public void Repaint() {
        this.removeAll();
        Point loc = new Point(50, 50);
        for (int i = 0; i < this.am.getStates().values().size(); ++i) {
            PropertyComponent sc = new PropertyComponent(this, String.valueOf((this.am.getStates()).keySet().toArray()[i]), loc);
            this.add(sc);
            loc.x = sc.getLocation().x + sc.getSize().width + 10;
            if (loc.x > (this.getWidth() - 50)) {
                loc.x = 50;
                loc.y += 50;
            }

            this.repaint();
        }
    }

    public ModelNode getNode() {
        return new AtomicModelNode(am.getName(), am.getChild(), am.getInputs(), am.getOutputs(), new Rectangle(this.getX(), this.getY(), this.getWidth(), this.getHeight()));
    }

    public void appendNodeIn(XmlDocument pere, ElementNode e) {
        getNode().appendMeIn(pere, e);
    }

    public AtomicModelComponent(AtomicModelNode prop, Model m) {
        super(prop);
         this.model = new AtomicClassLoader().getAtomic(prop.getType());
         am = (AtomicModel) model;
        am.declare(prop.getName(), (CoupledModel) m);
        src = new File(Project.projectpath + File.separator + "SRC" + File.separator + this.am.getName() + ".java");
        // mapping des ports par rapport a la def xml
        for (int i = 0; i < prop.getInputLength(); i++) {
            ((Port) am.getInputs().elementAt(i)).setName(prop.getInputAt(i));
        }

        for (int i = 0; i < prop.getOutputLength(); i++) {
            ((Port) am.getOutputs().elementAt(i)).setName(prop.getOutputAt(i));
        }

        this.setName(prop.getName());
        this.setBackground(new Color(146, 226, 147));
        Repaint();
        
      }

    public String getLibPath() {
        String lib = "";
        File root = new File(Project.projectpath + File.separator + "SRC" + File.separator + "lib");
        File[] list = root.listFiles();
        for (File f : list) {
            if (!f.isDirectory()) {
                if (FilenameUtils.isExtension(f.getName(), "jar")) {
                    lib += f.getAbsoluteFile() + ";";
                }
            }
        }
        if(!lib.equals(""))
        lib = "\"" + lib.substring(0, lib.length() - 1) + "\"";
        return lib;
    }

}
