/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelisator.modelisation;

import modelisator.data.CoupledModelNode;
import modelisator.data.ModelNode;
import com.sun.xml.tree.ElementNode;
import com.sun.xml.tree.XmlDocument;
import devsjava.modelisation.Model;
import devsjava.modelisation.Port;
import devsjava.modelisation.model.CoupledModel;
import devsjava.simulation.processor.Coordinator;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.Vector;

/**
 *
 * @author KACHER
 */
public class CoupledModelComponent extends ModelComponent {

    CoupledModel cm;

    public CoupledModelComponent(String name, Model parent, Point location, Dimension size) {
        super.model = new CoupledModel(name, parent);
        this.cm = (CoupledModel) super.model;
        this.setBounds(location.x, location.y, size.width, size.height);

    }

    public CoupledModelComponent() {
        super.model = new CoupledModel("root", null);
        this.cm = (CoupledModel) super.model;
    }

    public void paint(Graphics g) {
        super.paint(g);
        g.setColor(Color.darkGray);
        drawLinks(g);
        g.setFont(new Font("Arial", Font.BOLD, 12));

        String s = "CURRENT EVENTS : ";
        if (((Coordinator) cm.getProcess()).getECH().size() > 0) {
            for (int i = 0; i < cm.getInputs().size(); i++) {
                s += ((Coordinator) cm.getProcess()).getECH().elementAt(i).toString();
            }
            g.drawString(s, 5, this.getHeight() - 10);

        }
    }

    public void drawLinks(final Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setStroke(new BasicStroke(2, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2d.setColor(Color.GRAY);

        Point de = null;
        Point sr = null;
        Vector src = this.cm.getIn().getSrc();
        Vector dest = this.cm.getIn().getDest();
        for (int i = 0; i < src.size(); ++i) {
            int sx = 5;
            int sy = (super.model.getInputs().indexOf(src.elementAt(i)) + 1) * super.innbr;
            for (int u = 0; u < this.getComponents().length; ++u) {
                de = ((ModelComponent) this.getComponents()[u]).getPortLocation((Port) dest.elementAt(i));
                if (de != null) {
                    break;
                }
            }
            if (de != null) {
                g2d.drawLine(sx, sy + 5, (int) de.getX(), (int) de.getY() + 5);
            }
        }
        de = null;
        src = this.cm.getOut().getSrc();
        dest = this.cm.getOut().getDest();
        for (int i = 0; i < src.size(); ++i) {
            final int sx = this.getWidth() - 5;
            final int sy = (super.model.getOutputs().indexOf(dest.elementAt(i)) + 1) * super.outnbr;
            for (int u = 0; u < this.getComponents().length; ++u) {
                de = ((ModelComponent) this.getComponents()[u]).getPortLocation((Port) src.elementAt(i));
                if (de != null) {
                    break;
                }
            }
            if (de != null) {
                g2d.drawLine((int) de.getX(), (int) de.getY() + 5, sx, sy + 5);
            }
        }
        src = this.cm.getInt().getSrc();
        dest = this.cm.getInt().getDest();
        for (int i = 0; i < src.size(); ++i) {
            sr = de = null;
            for (int u = 0; u < this.getComponents().length; ++u) {
                if (sr == null) {
                    sr = ((ModelComponent) this.getComponents()[u]).getPortLocation((Port) src.elementAt(i));
                }
                if (de == null) {
                    de = ((ModelComponent) this.getComponents()[u]).getPortLocation((Port) dest.elementAt(i));
                }
                if (de != null && sr != null) {
                    g2d.drawLine((int) sr.getX(), (int) sr.getY() + 5, (int) de.getX(), (int) de.getY() + 5);
                }
            }
        }
    }

    public void setCoupling(int x, int y) {
        if (super.fromPort != null) {
            if (this.locateComponent(x, y) != null) {
                ModelComponent m = this.locateComponent(x, y);
                if (x - (int) m.getLocation().getX() < m.getWidth() / 2) {
                    super.toPort = m.findPort(x - (int) m.getLocation().getX(), y - (int) m.getLocation().getY());
                    if (super.toPort != null) {
                        ((CoupledModel) super.model).addCoupling("IN", super.fromPort, super.toPort);
                    }
                }
            } else if (this.getModel().getParent() != null) {
                ModelComponent m = (ModelComponent) this.getParent();
                ModelComponent mu = m.locateComponent(x + (int) this.getLocation().getX(), y + (int) this.getLocation().getY());
                if (mu == null) {
                    super.toPort = m.findPort(x + (int) this.getLocation().getX(), y + (int) this.getLocation().getY());
                    if (super.toPort != null) {
                        ((CoupledModel) m.getModel()).addCoupling("OUT", super.fromPort, super.toPort);
                    }
                } else if (mu != this) {
                    super.toPort = mu.findPort(x + (int) (this.getLocation().getX() - mu.getLocation().getX()), y + (int) (this.getLocation().getY() - mu.getLocation().getY()));
                    if (super.toPort != null) {
                        ((CoupledModel) m.getModel()).addCoupling("INT", super.fromPort, super.toPort);
                    }
                }
            }
        }
    }

    public ModelNode getNode() {
        CoupledModelNode cmn = new CoupledModelNode(cm.getName(), cm.getChild(), cm.getInputs(), cm.getOutputs(), cm.getIn(), cm.getOut(), cm.getInt(), new Rectangle(this.getX(), this.getY(), this.getWidth(), this.getHeight()));
        for (int i = this.getComponents().length - 1; i > -1; i--) {
            ((ModelComponent) this.getComponents()[i]).appendNodeIn(cmn.getDocument(), (ElementNode) cmn.getDocument().getDocumentElement().getElementsByTagName("CHILD").item(0));
        }
        return cmn;
    }

    public void appendNodeIn(XmlDocument pere, ElementNode father) {
        CoupledModelNode cmn = new CoupledModelNode(cm.getName(), cm.getChild(), cm.getInputs(), cm.getOutputs(), cm.getIn(), cm.getOut(), cm.getInt(), new Rectangle(this.getX(), this.getY(), this.getWidth(), this.getHeight()));
        ElementNode childNode = cmn.appendMeIn(pere, father);
        for (int i = this.getComponents().length - 1; i > -1; i--) {
            ((ModelComponent) this.getComponents()[i]).appendNodeIn(pere, childNode);
        }
    }

    public CoupledModelComponent(CoupledModelNode prop, Model m) {
        super(prop);
        this.model = new CoupledModel(prop.getName(), m);
        cm = (CoupledModel) model;
        this.setName(prop.getName());
        // mapping des ports par rapport a la def xml
        for (int i = 0; i < prop.getInputLength(); i++) {
            new Port(cm, prop.getInputAt(i), "IN");
        }

        for (int i = 0; i < prop.getOutputLength(); i++) {
            new Port(cm, prop.getOutputAt(i), "OUT");
        }
    }
}
