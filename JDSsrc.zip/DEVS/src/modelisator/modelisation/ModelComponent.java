/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelisator.modelisation;

import modelisator.utils.Editor.CodeEditor;
import modelisator.data.ModelNode;
import com.sun.xml.tree.ElementNode;
import com.sun.xml.tree.XmlDocument;
import devsjava.Entity;
import devsjava.modelisation.Model;
import devsjava.modelisation.Port;
import devsjava.modelisation.model.CoupledModel;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JViewport;
import javax.swing.SwingUtilities;
import modelisator.EditorWindow;

/**
 *
 * @author KACHER
 */
public abstract class ModelComponent extends JComponent implements MouseMotionListener, MouseListener {

    Model model;
    boolean selected;
    Port fromPort;
    Port toPort;

    protected int x;
    protected int y;

    protected int action;
    Image img;
    Graphics offg;
    protected int innbr;
    protected int outnbr;
    protected int mx;
    protected int my;

    public ModelComponent() {
        this.fromPort = null;
        this.toPort = null;
        selected = true;

        this.setBackground(Color.white);
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        setLayout(null);

    }

    @Override
    public void mouseClicked(MouseEvent e) {
        selected = true;
    }

    @Override
    public void mousePressed(MouseEvent e) {
        this.select();
        this.y = e.getY();
        this.x = e.getX();
        if (!(this.model.getParent() == null)) {
            this.action = 5;//deplacement
            setCursor(new Cursor(Cursor.MOVE_CURSOR));
        }
        if (e.getX() > this.getWidth() - 15 && e.getY() > this.getHeight() - 15) {//taille
            this.action = 4;
            setCursor(new Cursor(Cursor.SE_RESIZE_CURSOR));
        } else if (this.overMyPort(e.getX(), e.getY())) {//ports coordinations
            this.mx = this.x;
            this.my = this.y;
            this.action = 3;
            this.fromPort = this.findPort(e.getX(), e.getY());
            setCursor(new Cursor(Cursor.HAND_CURSOR));
        }
        if (e.getButton() == MouseEvent.BUTTON3) {
            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            this.refresh();
            this.action = 0;
            this.setComponentPopupMenu(null);
            if (this.overMyPort(e.getX(), e.getY())) {
                this.addPupupMenuPort(this.findPort(e.getX(), e.getY()));

            } else if (this.model.getChild().compareTo("mc") == 0) {
                int px = e.getX();
                int py = e.getY();

                if (px < 50) {
                    px = 50;
                }
                if (py < 50) {
                    py = 50;
                }
                if (px > (this.getSize().width - 200)) {
                    px = this.getSize().width - 200;
                }
                if (py > (this.getSize().height - 100)) {
                    py = this.getSize().height - 100;
                }
                this.addCoupledPupupMenuPort(px, py);
            } else {
                this.addAtomicPupupMenuPort();
            }

        }

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        if (action == 3 && overAPort(e.getX(), e.getY())) {//Coupling2ports
//            this.toPort = this.findPort(e.getX(), e.getY()); 

            this.toPort = null;
            this.setCoupling(e.getX(), e.getY());

        }
        this.action = 0;
        mx = 0;
        my = 0;
        this.y = 0;
        this.x = 0;
        this.refresh();
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (this.action == 5) {
            int nx = e.getX() + (int) this.getLocation().getX() - this.x;
            int ny = e.getY() + (int) this.getLocation().getY() - this.y;

            if (nx > ((this.getParent().getSize().width - this.getSize().width - 15))) {
                nx = ((this.getParent().getSize().width - this.getSize().width - 15));
            }
            if (ny > (this.getParent().getSize().height - this.getSize().height - 20)) {
                ny = (this.getParent().getSize().height - this.getSize().height - 20);
            }
            if (nx < 15) {
                nx = 15;
            }
            if (ny < 30) {
                ny = 30;
            }
            this.setLocation(nx, ny);
        }
        if (this.action == 4) {
            if (!(this.model.getParent() == null)) {
                int sx = e.getX() - (this.getX() - (int) this.getLocation().getX());
                int sy = e.getY() - (this.getY() - (int) this.getLocation().getY());

                if (sx > ((this.getParent().getSize().width - this.getLocation().x - 15))) {
                    sx = ((this.getParent().getSize().width - this.getLocation().x - 15));
                }
                if (sy > ((this.getParent().getSize().height - this.getLocation().y - 15))) {
                    sy = ((this.getParent().getSize().height - this.getLocation().y - 15));
                }
                if (sx < 100) {
                    sx = 100;
                }
                if (sy < 100) {
                    sy = 100;
                }
                this.setSize(sx, sy);
            } else {
                JViewport jv = (JViewport) this.getParent();
                Point p = jv.getViewPosition();
                Point pv = new Point((int) (this.getWidth() + (e.getPoint().getX() - this.x)),
                        (int) (this.getHeight() + (e.getPoint().getY() - this.y)));
                this.setPreferredSize(new Dimension(pv.x, pv.y));
                jv.setView(this);
                this.getParent().repaint();
            }
        }
        if (action == 3) {
            mx = e.getX();
            my = e.getY();
        }
        this.refresh();
    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }

    public void addPupupMenuPort(final Port p) {
        JPopupMenu menuPopup = new JPopupMenu();
        JMenuItem itm = new JMenuItem("Change port name");
        final ModelComponent mc = this;
        itm.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                PortPane d = new PortPane((JFrame) SwingUtilities.getWindowAncestor(mc), mc, p);
                d.setModal(true);
                d.show();
            }
        });
        menuPopup.add(itm);

        this.setComponentPopupMenu(menuPopup);
    }

    public void addCoupledPupupMenuPort(final int px, final int py) {
        final ModelComponent mc = this;
        JPopupMenu menuPopup = new JPopupMenu();
        JMenuItem itm = new JMenuItem("New Model");

        itm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NewModel nm = new NewModel((CoupledModel) mc.model, new Point(px, py));
            }
        });
        menuPopup.add(itm);
        JMenuItem itm1 = new JMenuItem("New Input Port");
        itm1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PortPane d = new PortPane((JFrame) SwingUtilities.getWindowAncestor(mc), "IN", mc);
                d.setModal(true);
                d.show();
            }
        });
        menuPopup.add(itm1);
        JMenuItem itm2 = new JMenuItem("New Output Port");
        itm2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PortPane d = new PortPane((JFrame) SwingUtilities.getWindowAncestor(mc), "OUT", mc);
                d.setModal(true);
                d.show();
            }
        });
        menuPopup.add(itm2);
        this.setComponentPopupMenu(menuPopup);
    }

    public void addAtomicPupupMenuPort() {
        JPopupMenu menuPopup = new JPopupMenu();
        final AtomicModelComponent mc = (AtomicModelComponent) this;

        JMenuItem itm1 = new JMenuItem("New Input Port");
        itm1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PortPane d = new PortPane((JFrame) SwingUtilities.getWindowAncestor(mc), "IN", mc);
                d.setModal(true);
                d.show();
            }
        });
        menuPopup.add(itm1);

        JMenuItem itm2 = new JMenuItem("New Output Port");
        itm2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {

                PortPane d = new PortPane((JFrame) SwingUtilities.getWindowAncestor(mc), "OUT", mc);
                d.setModal(true);
                d.show();
            }
        });
        menuPopup.add(itm2);
        JMenuItem itm5 = new JMenuItem("New Property");
        itm5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PropertyPane d = new PropertyPane((JFrame) SwingUtilities.getWindowAncestor(mc), mc);
                d.setModal(true);
                d.show();
            }
        });
        menuPopup.add(itm5);
        if (!(mc.src == null)) {
            JMenuItem itm3 = new JMenuItem("Source Code");
            itm3.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    new CodeEditor(mc.src);
                }
            });
            menuPopup.add(itm3);
            JMenuItem itm4 = new JMenuItem("Compile");
            itm4.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    mc.compile();
                }
            });
            menuPopup.add(itm4);
        } else {
            JMenuItem itm3 = new JMenuItem("Generate Code");
            itm3.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    mc.generateJavaCode();
                }
            });
            menuPopup.add(itm3);
        }

        this.setComponentPopupMenu(menuPopup);
    }

    public Model getModel() {
        return model;
    }

    public void setModel(Model model) {
        this.model = model;
    }

    public void unselectAll() {
        this.selected = false;
        for (int i = 0; i < this.getComponents().length; ++i) {
            if (!this.getComponents()[i].getClass().getSimpleName().equals("PropertyComponent")) {
                ((ModelComponent) this.getComponents()[i]).unselectAll();
            }
        }
    }

    public ModelComponent locateComponent(int x, int y) {
        for (int i = 0; i < this.getComponents().length; ++i) {
            if (((ModelComponent) this.getComponents()[i]).getBounds().contains(x, y)) {
                return (ModelComponent) this.getComponents()[i];
            }
        }
        return null;
    }

    public void select() {
        if (this.getModel().getParent() == null) {
            this.select(this);

        } else {
            ((ModelComponent) this.getParent()).select(this);
        }
        EditorWindow.ModelbtnEnable(this.model.getChild().compareTo("mc") == 0);
    }

    public void select(final ModelComponent m) {
        if (this.getModel().getParent() == null) {
            ((WorkSpace) this.getParent().getParent()).setSelected(m);

        } else {
            ((ModelComponent) this.getParent()).select(m);
        }
    }

    public void refresh() {
        this.getParent().repaint();
    }

    public abstract void setCoupling(int p0, int p1);

    public void drawLine(final Graphics g) {
        if (action == 3) {
            g.setColor(Color.RED);
            if (this.x < this.getWidth() / 2) {
                g.drawLine(5, this.innbr * (this.y / this.innbr) + 5, this.mx, this.my);
            } else if (this.getModel().getParent() != null) {
                ModelComponent par = (ModelComponent) this.getParent();
                par.offg.setColor(Color.RED);
                par.offg.drawLine((int) this.getLocation().getX() + this.getWidth() - 5, (int) this.getLocation().getY() + this.outnbr * (this.y / this.outnbr) + 5, (int) this.getLocation().getX() + this.mx, (int) this.getLocation().getY() + this.my);
                ((ModelComponent) this.getParent()).repaint();
            }
        }
    }

    public Point getPortLocation(Port p) {
        if (this.model.getInputs().contains(p)) {
            return new Point((int) this.getLocation().getX() + 5, (int) this.getLocation().getY() + (this.model.getInputs().indexOf(p) + 1) * this.innbr);
        }
        if (this.model.getOutputs().contains(p)) {
            return new Point((int) this.getLocation().getX() + this.getWidth() - 5, (int) this.getLocation().getY() + (this.model.getOutputs().indexOf(p) + 1) * this.outnbr);
        }
        return null;
    }

    public boolean overAPort(int x, int y) {
        return this.overMyPort(x, y) || this.overChildPort(x, y) || this.overParentPort(x, y) || this.overBrotherPort(x, y);
    }

    public boolean overChildPort(int x, int y) {
        if (this.model.getChild().compareTo("mc") != 0) {
            return false;
        }
        for (int i = 0; i < this.getComponents().length; ++i) {
            ModelComponent mi = (ModelComponent) this.getComponents()[i];
            if (mi.overMyPort(x - (int) mi.getLocation().getX(), y - (int) mi.getLocation().getY())) {
                return true;
            }
        }
        return false;

    }

    public boolean overParentPort(int x, int y) {
        if (this.model.getParent() != null) {
            ModelComponent mi = (ModelComponent) this.getParent();
            return mi.overMyPort(x + (int) this.getLocation().getX(), y + (int) this.getLocation().getY());
        }

        return false;
    }

    public boolean overBrotherPort(int x, int y) {
        if (this.model.getParent() != null) {
            ModelComponent mi = (ModelComponent) this.getParent();
            return mi.overChildPort(x + (int) this.getLocation().getX(), y + (int) this.getLocation().getY());
        }
        return false;
    }

    public boolean overMyPort(int x, int y) {
        for (int i = 0; i < this.model.getInputs().size(); ++i) {
            if (new Rectangle(0, i * this.innbr + this.innbr, 10, 10).contains(x, y)) {
                return true;
            }
        }
        for (int i = 0; i < this.model.getOutputs().size(); ++i) {
            if (new Rectangle(this.getWidth() - 10, i * this.outnbr + this.outnbr, 10, 10).contains(x, y)) {
                return true;
            }
        }
        return false;
    }

    public Port findPort(int x, int y) {
        Port p = null;
        if (this.outnbr != this.getHeight() && x > this.getWidth() / 2) {

            p = (Port) this.model.getOutputs().elementAt((y - this.outnbr) / this.outnbr);
            return p;

        }
        if (this.innbr != this.getHeight() && x < this.getWidth() / 2) {

            p = (Port) this.model.getInputs().elementAt((y - this.innbr) / this.innbr);
            return p;
        }
        return null;
    }

    public void paint(final Graphics g) {
        this.img = this.createImage(this.getWidth(), this.getHeight());
        this.offg = g;
        this.offg.setColor(Color.black);
        this.offg.fillRect(0, 0, this.getWidth(), this.getHeight());

        this.offg.setColor(this.getBackground());
        this.offg.fillRect(1, 1, this.getWidth() - 2, this.getHeight() - 2);
        this.offg.setColor(this.getBackground());
        this.offg.fillRect(1, 1, this.getWidth() - 2, 15);
        this.offg.setColor(Color.black);
        this.offg.drawLine(0, 16, this.getWidth(), 16);

        this.offg.setColor(Color.black);
        for (int i = 15; i > 0; i -= 2) {
            this.offg.drawLine(this.getWidth() - i, this.getHeight(), this.getWidth(), this.getHeight() - i);
        }
        if (this.selected) {
            this.offg.setColor(Color.red);
            this.offg.setFont(new Font("Arial", 1, 15));
            this.offg.drawString(this.model.getName(), 5, 13);
        } else {
            this.offg.setColor(Color.black);
            this.offg.setFont(new Font("Arial", 0, 15));
            this.offg.drawString(this.model.getName(), 5, 13);
        }
        this.offg.setFont(new Font("Arial", 0, 15));

        this.drawLine(this.offg);
        this.offg.setColor(Color.red);
        this.innbr = this.getHeight() / (this.model.getInputs().size() + 1);
        for (int i = 0; i < this.model.getInputs().size(); ++i) {

            this.offg.fillRect(0, i * this.innbr + this.innbr, 10, 10);
            this.offg.drawString(String.valueOf((Port) this.model.getInputs().elementAt(i)), 12, i * this.innbr + this.innbr + 10);
        }

        this.outnbr = this.getHeight() / (this.model.getOutputs().size() + 1);
        for (int i = 0; i < this.model.getOutputs().size(); ++i) {
            this.offg.fillRect(this.getWidth() - 10, i * this.outnbr + this.outnbr, 10, 10);
            String s = String.valueOf((Port) this.model.getOutputs().elementAt(i));
            this.offg.drawString(s, this.getWidth() - (s.length() * 9) - 15, i * this.outnbr + this.outnbr + 10);
        }
        super.paint(this.offg);

    }
//--------------------------------------------------------------------

    public abstract ModelNode getNode();

    public abstract void appendNodeIn(XmlDocument pere, ElementNode father);

    public ModelComponent(ModelNode prop) {
        this();
        this.setBounds(prop.getBounds());
    }
}
