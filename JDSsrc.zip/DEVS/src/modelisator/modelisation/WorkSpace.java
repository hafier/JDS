/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelisator.modelisation;

import modelisator.EditorWindow;
import devsjava.modelisation.Model;
import devsjava.modelisation.model.CoupledModel;
import java.awt.BorderLayout;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

/**
 *
 * @author KACHER
 */
public class WorkSpace extends JScrollPane {

    public CoupledModelComponent rootmodel;
    public ModelComponent selectedModel;
    static int am = -1;
    static int cm = -1;

    public WorkSpace() {
        am = -1;
        cm = -1;
        this.rootmodel = new CoupledModelComponent();
        this.selectedModel = this.rootmodel;
        setViewportView(this.rootmodel);
    }

    public void New() {

        this.rootmodel = new CoupledModelComponent();
        this.selectedModel = this.rootmodel;
        setViewportView(this.rootmodel);
        setSelected(this.selectedModel);
        repaint();

    }

    public void Load(CoupledModelComponent root) {

        this.rootmodel = root;
        this.selectedModel = this.rootmodel;
        setViewportView(this.rootmodel);
        setSelected(this.selectedModel);
        repaint();

    }

    public ModelComponent getSelected() {
        return this.selectedModel;
    }

    public void addModelComponent(ModelComponent comp) {

        this.selectedModel.add(comp);
        ((CoupledModel) this.selectedModel.getModel()).addComposition(comp.getModel());
        comp.setVisible(true);
        this.setSelected(comp);
        this.repaint();

    }

    public void setSelected(ModelComponent m) {
        this.selectedModel = m;
        this.rootmodel.unselectAll();
        m.selected = true;
        ((EditorWindow) SwingUtilities.getWindowAncestor(this)).setModelPanel();

    }

    public CoupledModelComponent getModelComponent() {
        return this.rootmodel;
    }
}
