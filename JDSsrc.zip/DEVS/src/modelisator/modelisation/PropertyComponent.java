/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelisator.modelisation;

/**
 *
 * @author KACHER
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.IOException;
import java.util.Hashtable;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;

/**
 *
 * @author KACHER
 */
public class PropertyComponent extends JLabel implements MouseMotionListener, MouseListener {

    static boolean b = true;
    static Color activated = new Color(143, 0, 0);
    static Color deactivated = new Color(43, 115, 21);
    Color selectedColor;
    protected int x;
    protected int y;
    String key;
    AtomicModelComponent ac;
    public Point location;

    public PropertyComponent(AtomicModelComponent ac, String key, Point location) {
        this.key = key;
        this.ac = ac;
        this.location = location;
        this.setBounds(this.location.x, this.location.y, 100, 50);
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
        addPupupMenu();
    }

    public void addPupupMenu() {

        JPopupMenu menuPopup = new JPopupMenu();
        JMenuItem itm = new JMenuItem("Change property");

        itm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itmActionPerformed(evt);
            }
        });
        menuPopup.add(itm);

        this.setComponentPopupMenu(menuPopup);
    }

    private void itmActionPerformed(java.awt.event.ActionEvent evt) {
        PropertyPane d = new PropertyPane((JFrame) SwingUtilities.getWindowAncestor(this), this.key, ac);
        d.setModal(true);
        d.show();
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        int nx = e.getX() + (int) this.getLocation().getX() - this.x;
        int ny = e.getY() + (int) this.getLocation().getY() - this.y;

        if (nx > ((this.getParent().getSize().width - this.getSize().width - 1))) {
            nx = ((this.getParent().getSize().width - this.getSize().width - 1));
        }
        if (ny > (this.getParent().getSize().height - this.getSize().height - 20)) {
            ny = (this.getParent().getSize().height - this.getSize().height - 20);
        }
        if (nx < 1) {
            nx = 1;
        }
        if (ny < 17) {
            ny = 17;
        }
        this.setLocation(nx, ny);

    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        ((ModelComponent) this.getParent()).selected = true;

        this.y = e.getY();
        this.x = e.getX();
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        ((ModelComponent) this.getParent()).select();
        ((ModelComponent) this.getParent()).refresh();
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    public void paint(final Graphics g) {
        super.paint(g);
        if (this.ac.am.getStates().values().size() > 0 && this.ac.am.getStates().containsKey(this.key)) {
            FontMetrics fm = g.getFontMetrics();
            String value = String.valueOf(this.ac.am.getStates().get(this.key));
            int x = 0;
            int y = 0;
            g.setColor(deactivated);

            int size = (int) fm.stringWidth(this.key);
            if (((int) fm.stringWidth(value)) > ((int) fm.stringWidth(this.key))) {
                size = (int) fm.stringWidth(value);
            }
            g.fillRect(x, y, size + 40, (int) fm.getHeight() + 20);
            g.setColor(Color.white);
            g.drawString(this.key, x + 20, y + fm.getAscent());
            g.setColor(Color.yellow);
            g.drawString(value, x + 20, y + 15 + fm.getAscent());
            this.setBounds(this.getLocation().x, this.getLocation().y, size + 40, (int) fm.getHeight() + 20);
            g.setColor(Color.white);
            g.drawRect(0, 0, this.getWidth() - 1, this.getHeight() - 1);
            this.getParent().repaint();

        }

    }

}
