package modelisator.utils;

import modelisator.Project;
import modelisator.EditorWindow;
import java.io.*;
import devsjava.modelisation.model.*;

/**
 *
 * @author KACHER
 */
public class AtomicClassLoader extends ClassLoader {

    String path;

    public Class findClass(String name) {
        byte[] b = loadClassData(name);
        return defineClass(name, b, 0, b.length);
    }

    private byte[] loadClassData(String name) {
        byte[] b = null;
        FileInputStream in;

        try {
            in = new FileInputStream(path + File.separator + name + ".class");
            b = new byte[in.available()];
            in.read(b);
        } catch (FileNotFoundException e) {
            EditorWindow.c.ShowMsg(e.getMessage());
        } catch (IOException ee) {
            EditorWindow.c.ShowMsg(ee.getMessage());
        }
        return b;

    }

    public AtomicModel getAtomic(String name) {
        this.path = Project.projectpath + File.separator + "ATOMICS";
        Object o = null;
        try {
            o = loadClass(name).newInstance();
        } catch (ClassNotFoundException e) {
            EditorWindow.c.ShowMsg("Error de creation de classe" + e.toString());
        } catch (IllegalAccessException e1) {
            EditorWindow.c.ShowMsg("erreur d'acces" + e1.toString());
        } catch (InstantiationException e2) {
            EditorWindow.c.ShowMsg("erreur d'instanciation" + e2.toString());
        }
        return (AtomicModel) o;
    }

}
