/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelisator.utils;

/**
 *
 * @author KACHER
 */
import modelisator.modelisation.AtomicModelComponent;
import modelisator.modelisation.CoupledModelComponent;
import modelisator.data.CoupledModelNode;
import modelisator.data.AtomicModelNode;
import java.io.*;
import java.util.*;
import devsjava.modelisation.*;
import devsjava.modelisation.model.*;
import com.sun.xml.tree.*;

public class xmlLoader {

    public XmlDocument doc;

    public xmlLoader(String nomFichier) {
        try {
            doc = new XmlDocument().createXmlDocument(new FileInputStream(nomFichier), true);
        } catch (Exception err) {
            System.out.println(err);
        }
    }

    public CoupledModelComponent getDocumentComponents(CoupledModelComponent cm) {
        if (cm == null) {
            return getCoupled((ElementNode) doc.getDocumentElement(), null);
        }
        return getCoupled((ElementNode) doc.getDocumentElement(), cm.getModel());
    }

    private CoupledModelComponent getCoupled(ElementNode root, Model father) {
        CoupledModelNode cmn = new CoupledModelNode(root);
        CoupledModelComponent cm = new CoupledModelComponent(cmn, father);
        for (int i = 0; i < ((ElementNode) root.getElementsByTagName("CHILD").item(0)).getChildNodes().getLength(); i++) {
            if (((ElementNode) root.getElementsByTagName("CHILD").item(0)).getChildNodes().item(i).getNodeName().equals("MODEL")) {
                ElementNode current = ((ElementNode) ((ElementNode) root.getElementsByTagName("CHILD").item(0)).getChildNodes().item(i));
                if (current.getElementsByTagName("TYPE").item(0).getFirstChild().getNodeValue().compareTo("mc") == 0) {
                    cm.add(getCoupled(current, cm.getModel()));
                } else {
                    AtomicModelComponent am = new AtomicModelComponent(new AtomicModelNode(current), cm.getModel());
                    cm.add(am);
                    ((CoupledModel) cm.getModel()).addComposition(am.getModel());
                }
            }
        }

        cmn.getNode().removeChild(((ElementNode) cmn.getNode().getElementsByTagName("CHILD").item(0)));

        // initialise les liens
        if (cmn.hasLink("IN")) {
            for (int i = 0; i < cmn.getLinkLength("IN"); i++) {
                Port fromport = null;
                Port toport = null;
                fromport = cm.getModel().getPortByName(cm.getName() + "." + cmn.getLinkSrcName("IN", i));
                Vector cmChild = ((CoupledModel) cm.getModel()).getChildren();
                for (int u = 0; u < cmChild.size(); u++) {
                    if (toport == null) {
                        toport = ((Model) cmChild.elementAt(u)).getPortByName(((Model) cmChild.elementAt(u)).getName() + "." + cmn.getLinkDestName("IN", i));
                    }
                }
                if ((toport != null) && (fromport != null)) {
                    ((CoupledModel) cm.getModel()).addCoupling("IN", fromport, toport);
                }
            }
        }

        if (cmn.hasLink("OUT")) {
            for (int i = 0; i < cmn.getLinkLength("OUT"); i++) {
                Port fromport = null;
                Port toport = null;
                toport = cm.getModel().getPortByName(cm.getName() + "." + cmn.getLinkDestName("OUT", i));
                Vector cmChild = ((CoupledModel) cm.getModel()).getChildren();
                for (int u = 0; u < cmChild.size(); u++) {
                    if (fromport == null) {
                        fromport = ((Model) cmChild.elementAt(u)).getPortByName(((Model) cmChild.elementAt(u)).getName() + "." + cmn.getLinkSrcName("OUT", i));
                    }
                }
                if ((toport != null) && (fromport != null)) {
                    ((CoupledModel) cm.getModel()).addCoupling("OUT", fromport, toport);
                }
            }
        }

        if (cmn.hasLink("INT")) {
            for (int i = 0; i < cmn.getLinkLength("INT"); i++) {
                Port fromport = null;
                Port toport = null;
                Vector cmChild = ((CoupledModel) cm.getModel()).getChildren();
                for (int u = 0; u < cmChild.size(); u++) {
                    if (fromport == null) {
                        fromport = ((Model) cmChild.elementAt(u)).getPortByName(((Model) cmChild.elementAt(u)).getName() + "." + cmn.getLinkSrcName("INT", i));
                    }
                    if (toport == null) {
                        toport = ((Model) cmChild.elementAt(u)).getPortByName(((Model) cmChild.elementAt(u)).getName() + "." + cmn.getLinkDestName("INT", i));
                    }
                }
                if ((toport != null) && (fromport != null)) {
                    ((CoupledModel) cm.getModel()).addCoupling("INT", fromport, toport);
                }
            }
        }

        return cm;
    }

}
