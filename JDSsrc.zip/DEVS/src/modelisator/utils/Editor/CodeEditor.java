/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelisator.utils.Editor;

import modelisator.utils.Editor.TextLineNumber;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Element;
import javax.swing.text.JTextComponent;
import javax.swing.text.StyleConstants;
import javax.swing.text.Utilities;
import modelisator.utils.CopyPastPopupMenu;

/**
 *
 * @author ThinkPad
 */
public class CodeEditor extends JFrame {

    private JMenuBar jMenuBar1;
    private JMenu jMenu1;
    private JMenuItem jMenuItem2;
    private JMenuItem jMenuItem3;
    String str = "";
    String temp = "";
    File f;
    private final JTextPane textPane;
    
    public CodeEditor(File f) {
            this.setIconImage(Toolkit.getDefaultToolkit().createImage(getClass().getResource("/modelisator/icons/I.png")));

        textPane = new JTextPane();
        textPane.setFont(new java.awt.Font("Consolas", 0, 14));
        initComponents();
        new CopyPastPopupMenu(this.textPane);
        this.f = f;
//        File fname1 = new File("C:\\Users\\ThinkPad\\Desktop\\mod\\sources\\composant.java");
        try {
            FileReader fr = new FileReader(this.f.getPath());
            BufferedReader bf = new BufferedReader(fr);
            while ((str = bf.readLine()) != null) {
                temp = temp + str + "\n";
            }
            fr.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(CodeEditor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CodeEditor.class.getName()).log(Level.SEVERE, null, ex);
        }

        this.textPane.setText(temp);
        this.setTitle(f.getName());
        setVisible(true);
    }

    public void initComponents() {
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {

            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        jMenu1.setText("File");

        jMenuItem2.setText("Open");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setText("Save");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        JScrollPane scrollPane = new JScrollPane(textPane);
        TextLineNumber tln = new TextLineNumber(textPane);
        scrollPane.setRowHeaderView(tln);
        getContentPane().add(scrollPane);
        getContentPane().repaint();
        setSize(600, 600);

        setLocationRelativeTo(null);
    }

    private void formWindowClosing(java.awt.event.WindowEvent evt) {
        int rep = JOptionPane.showConfirmDialog(null, "Save?", "Confirmation", JOptionPane.YES_NO_OPTION);
        if (rep == JOptionPane.YES_OPTION) {
            Save();
        } else if (rep == JOptionPane.NO_OPTION) {
            this.dispose();
        }
    }

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {
        Save();

    }

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            JFileChooser jfc1 = new JFileChooser();
            jfc1.showOpenDialog(this);
            File fname1 = jfc1.getSelectedFile();
            FileReader fr = new FileReader(fname1.getPath());
            BufferedReader bf = new BufferedReader(fr);
            while ((str = bf.readLine()) != null) {
                temp = temp + str + "\n";
            }
            fr.close();
            this.textPane.setText(temp);
            setTitle(fname1.getPath());

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void Save() {
        String str_gettext = this.textPane.getText();

        try {
            BufferedWriter out = new BufferedWriter(new FileWriter(this.f));
            out.write(str_gettext);
            out.close();
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
//-------------------------------------------------------------------------------
    
}

