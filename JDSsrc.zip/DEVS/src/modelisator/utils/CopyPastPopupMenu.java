/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelisator.utils;

import javax.swing.JPopupMenu;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;

/**
 *
 * @author KACHER
 */
public class CopyPastPopupMenu extends JPopupMenu {

    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;

    public CopyPastPopupMenu(final JTextField textfield) {
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem1.setText("Couper");
        jMenuItem1.setToolTipText("");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textfield.cut();
            }
        });
        this.add(jMenuItem1);
        jMenuItem2.setText("Copier");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textfield.copy();
            }
        });
        add(jMenuItem2);

        jMenuItem3.setText("Coller");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textfield.paste();
            }
        });
        add(jMenuItem3);
        textfield.setComponentPopupMenu(this);
    }

    public CopyPastPopupMenu(final JTextPane textPane) {

        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem1.setText("Couper");
        jMenuItem1.setToolTipText("");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textPane.cut();
            }
        });
        this.add(jMenuItem1);
        jMenuItem2.setText("Copier");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textPane.copy();
            }
        });
        add(jMenuItem2);

        jMenuItem3.setText("Coller");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textPane.paste();
            }
        });
        add(jMenuItem3);
        textPane.setComponentPopupMenu(this);
    }

    public CopyPastPopupMenu(final JTextArea jTextArea1) {

        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem1.setText("Couper");
        jMenuItem1.setToolTipText("");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextArea1.cut();
            }
        });
        this.add(jMenuItem1);
        jMenuItem2.setText("Copier");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextArea1.copy();
            }
        });
        add(jMenuItem2);

        jMenuItem3.setText("Coller");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextArea1.paste();
            }
        });
        add(jMenuItem3);
        jTextArea1.setComponentPopupMenu(this);
    }

}
