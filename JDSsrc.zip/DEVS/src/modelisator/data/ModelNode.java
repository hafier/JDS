/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelisator.data;

import java.awt.*;
import com.sun.xml.tree.*;
import java.util.*;
import devsjava.modelisation.model.*;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;
import devsjava.*;

public abstract class ModelNode {

    ElementNode e;
    ElementNode port;
    XmlDocument doc;

    public ModelNode() { // constructeur pour la creation de fichier vide
        try {
            doc = XmlDocument.createXmlDocument(ModelNode.class.getResourceAsStream("model.xml"), true);
        } catch (Exception e) {
            System.out.println(e);
        }
        e = ((ElementNode) doc.getDocumentElement());
        port = (ElementNode) doc.createElementEx("PORT");
        port.appendChild(doc.createTextNode("void"));
    }

    public ModelNode(String name, String type, Vector input, Vector output, Rectangle loc) { // constructeur pour la generation de fichier
        try {
            doc = XmlDocument.createXmlDocument(ModelNode.class.getResourceAsStream("model.xml"), true);
        } catch (Exception e) {
            System.out.println(e);
        }
        e = ((ElementNode) doc.getDocumentElement());
        port = (ElementNode) doc.createElementEx("PORT");
        port.appendChild(doc.createTextNode("void"));

        e.getElementsByTagName("LOCX").item(0).getFirstChild().setNodeValue(new Integer((int) loc.getX()).toString());
        e.getElementsByTagName("LOCY").item(0).getFirstChild().setNodeValue(new Integer((int) loc.getY()).toString());
        e.getElementsByTagName("WIDTH").item(0).getFirstChild().setNodeValue(new Integer((int) loc.getWidth()).toString());
        e.getElementsByTagName("HEIGHT").item(0).getFirstChild().setNodeValue(new Integer((int) loc.getHeight()).toString());
        e.getElementsByTagName("TYPE").item(0).getFirstChild().setNodeValue(type);
        e.getElementsByTagName("NAME").item(0).getFirstChild().setNodeValue(name);

        for (int i = 0; i < input.size(); i++) {
            port.getFirstChild().setNodeValue(((Port) input.elementAt(i)).toString());
            e.getElementsByTagName("INPUT").item(0).appendChild(port.cloneNode(true));
        }

        for (int i = 0; i < output.size(); i++) {
            port.getFirstChild().setNodeValue(((Port) output.elementAt(i)).toString());
            e.getElementsByTagName("OUTPUT").item(0).appendChild(port.cloneNode(true));
        }
    }

    public ModelNode(ElementNode e) { // constructeurutile au chargement a partir d'un fichier
        this.e = e;
    }

    public int getX() {
        return new Integer(e.getElementsByTagName("LOCX").item(0).getFirstChild().toString()).intValue();
    }

    public int getY() {
        return new Integer(e.getElementsByTagName("LOCY").item(0).getFirstChild().toString()).intValue();
    }

    public int getHeight() {
        return new Integer(e.getElementsByTagName("HEIGHT").item(0).getFirstChild().toString()).intValue();
    }

    public int getWidth() {
        return new Integer(e.getElementsByTagName("WIDTH").item(0).getFirstChild().toString()).intValue();
    }

    public String getName() {
        return e.getElementsByTagName("NAME").item(0).getFirstChild().toString();
    }

    public String getType() {
        return e.getElementsByTagName("TYPE").item(0).getFirstChild().toString();
    }

    public String getInputAt(int i) {
        return ((ElementNode) e.getElementsByTagName("INPUT").item(0)).getElementsByTagName("PORT").item(i).getFirstChild().getNodeValue();
    }

    public String getOutputAt(int i) {
        return ((ElementNode) e.getElementsByTagName("OUTPUT").item(0)).getElementsByTagName("PORT").item(i).getFirstChild().getNodeValue();
    }

    public int getOutputLength() {
        return ((ElementNode) e.getElementsByTagName("OUTPUT").item(0)).getElementsByTagName("PORT").getLength();
    }

    public int getInputLength() {
        return ((ElementNode) e.getElementsByTagName("INPUT").item(0)).getElementsByTagName("PORT").getLength();
    }

    public Rectangle getBounds() {
        return new Rectangle(getX(), getY(), getWidth(), getHeight());
    }

    public String toString() {
        return e.toString();
    }

    public abstract ElementNode appendMeIn(XmlDocument pere, ElementNode father);

    public ElementNode getNode() {
        return e;
    }

    void addNodeIn(String nodeName, String value, ElementNode parent, XmlDocument pere) {
        ElementNode temp = (ElementNode) pere.createElementEx(nodeName);
        temp.appendChild(pere.createTextNode(value));
        parent.appendChild(temp);
    }

    public XmlDocument getDocument() {
        return doc;
    }

}
