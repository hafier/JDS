package modelisator.data;

import devsjava.modelisation.*;
import java.awt.*;
import com.sun.xml.tree.*;
import java.util.*;

public class CoupledModelNode extends ModelNode {

    ElementNode link;

    public CoupledModelNode(ElementNode e) {
        super(e);
    }

    public CoupledModelNode(String name, String type, Vector input, Vector output, Coupling eic, Coupling eoc, Coupling ic, Rectangle loc) {
        try {
            doc = XmlDocument.createXmlDocument(CoupledModelNode.class.getResourceAsStream("coupled.xml"), true);
        } catch (Exception e) {
            System.out.println(e);
        }
        e = ((ElementNode) doc.getDocumentElement());
        link = (ElementNode) doc.createElementEx("LINK");
        port = (ElementNode) doc.createElementEx("PORT");
        port.appendChild(doc.createTextNode("void"));
        link.appendChild(port.cloneNode(true));
        link.appendChild(port.cloneNode(true));

        e.getElementsByTagName("LOCX").item(0).getFirstChild().setNodeValue(new Integer((int) loc.getX()).toString());
        e.getElementsByTagName("LOCY").item(0).getFirstChild().setNodeValue(new Integer((int) loc.getY()).toString());
        e.getElementsByTagName("WIDTH").item(0).getFirstChild().setNodeValue(new Integer((int) loc.getWidth()).toString());
        e.getElementsByTagName("HEIGHT").item(0).getFirstChild().setNodeValue(new Integer((int) loc.getHeight()).toString());
        e.getElementsByTagName("TYPE").item(0).getFirstChild().setNodeValue(type);
        e.getElementsByTagName("NAME").item(0).getFirstChild().setNodeValue(name);

        for (int i = 0; i < input.size(); i++) {
            port.getFirstChild().setNodeValue(((Port) input.elementAt(i)).toString());
            e.getElementsByTagName("INPUT").item(0).appendChild(port.cloneNode(true));
        }

        for (int i = 0; i < output.size(); i++) {
            port.getFirstChild().setNodeValue(((Port) output.elementAt(i)).toString());
            e.getElementsByTagName("OUTPUT").item(0).appendChild(port.cloneNode(true));
        }

        for (int i = 0; i < eic.getLg(); i++) {
            link.getElementsByTagName("PORT").item(0).getFirstChild().setNodeValue(eic.getName("SOURCE", i).toString());
            link.getElementsByTagName("PORT").item(1).getFirstChild().setNodeValue(eic.getName("DESTINATION", i).toString());
            e.getElementsByTagName("EIC").item(0).appendChild(link.cloneNode(true));
        }

        for (int i = 0; i < eoc.getLg(); i++) {
            link.getElementsByTagName("PORT").item(0).getFirstChild().setNodeValue(eoc.getName("SOURCE", i).toString());
            link.getElementsByTagName("PORT").item(1).getFirstChild().setNodeValue(eoc.getName("DESTINATION", i).toString());
            e.getElementsByTagName("EOC").item(0).appendChild(link.cloneNode(true));
        }

        for (int i = 0; i < ic.getLg(); i++) {
            link.getElementsByTagName("PORT").item(0).getFirstChild().setNodeValue(ic.getName("SOURCE", i).toString());
            link.getElementsByTagName("PORT").item(1).getFirstChild().setNodeValue(ic.getName("DESTINATION", i).toString());
            e.getElementsByTagName("IC").item(0).appendChild(link.cloneNode(true));
        }

    }

    public boolean hasLink(String loc) {
        if (loc.compareTo("IN") == 0) {
            return ((ElementNode) e.getElementsByTagName("EIC").item(0)) != null;
        }
        if (loc.compareTo("OUT") == 0) {
            return ((ElementNode) e.getElementsByTagName("EOC").item(0)) != null;
        }
        if (loc.compareTo("INT") == 0) {
            return ((ElementNode) e.getElementsByTagName("IC").item(0)) != null;
        }

        return false;
    }

    public String getLinkSrcName(String loc, int linkindex) {
        if (loc.compareTo("IN") == 0) {
            return ((ElementNode) ((ElementNode) e.getElementsByTagName("EIC").item(0)).getElementsByTagName("LINK").item(linkindex)).getElementsByTagName("PORT").item(0).getFirstChild().getNodeValue();
        }

        if (loc.compareTo("OUT") == 0) {
            return ((ElementNode) ((ElementNode) e.getElementsByTagName("EOC").item(0)).getElementsByTagName("LINK").item(linkindex)).getElementsByTagName("PORT").item(0).getFirstChild().getNodeValue();
        }

        if (loc.compareTo("INT") == 0) {
            return ((ElementNode) ((ElementNode) e.getElementsByTagName("IC").item(0)).getElementsByTagName("LINK").item(linkindex)).getElementsByTagName("PORT").item(0).getFirstChild().getNodeValue();
        }

        return null;
    }

    public String getLinkDestName(String loc, int linkindex) {
        if (loc.compareTo("IN") == 0) {
            return ((ElementNode) ((ElementNode) e.getElementsByTagName("EIC").item(0)).getElementsByTagName("LINK").item(linkindex)).getElementsByTagName("PORT").item(1).getFirstChild().getNodeValue();
        }
        if (loc.compareTo("OUT") == 0) {
            return ((ElementNode) ((ElementNode) e.getElementsByTagName("EOC").item(0)).getElementsByTagName("LINK").item(linkindex)).getElementsByTagName("PORT").item(1).getFirstChild().getNodeValue();
        }
        if (loc.compareTo("INT") == 0) {
            return ((ElementNode) ((ElementNode) e.getElementsByTagName("IC").item(0)).getElementsByTagName("LINK").item(linkindex)).getElementsByTagName("PORT").item(1).getFirstChild().getNodeValue();
        }
        return null;
    }

    public int getLinkLength(String loc) {
        if (loc.compareTo("IN") == 0) {
            return ((ElementNode) e.getElementsByTagName("EIC").item(0)).getElementsByTagName("LINK").getLength();
        }
        if (loc.compareTo("OUT") == 0) {
            return ((ElementNode) e.getElementsByTagName("EOC").item(0)).getElementsByTagName("LINK").getLength();
        }
        if (loc.compareTo("INT") == 0) {
            return ((ElementNode) e.getElementsByTagName("IC").item(0)).getElementsByTagName("LINK").getLength();
        }
        return 0;
    }

    public ElementNode appendMeIn(XmlDocument pere, ElementNode father) {
        ElementNode mdl = (ElementNode) pere.createElementEx("MODEL");
        mdl.appendChild(pere.createTextNode("\n\t\t"));
        addNodeIn("TYPE", getType(), mdl, pere);
        mdl.appendChild(pere.createTextNode("\n\t\t"));
        addNodeIn("NAME", getName(), mdl, pere);
        mdl.appendChild(pere.createTextNode("\n\t\t"));
        ElementNode bounds = (ElementNode) pere.createElementEx("BOUNDS");
        addNodeIn("LOCX", new Integer(getX()).toString(), bounds, pere);
        addNodeIn("LOCY", new Integer(getY()).toString(), bounds, pere);
        addNodeIn("WIDTH", new Integer(getWidth()).toString(), bounds, pere);
        addNodeIn("HEIGHT", new Integer(getHeight()).toString(), bounds, pere);
        mdl.appendChild(bounds);
        ElementNode input = (ElementNode) pere.createElementEx("INPUT");
        for (int i = 0; i < this.getInputLength(); i++) {
            addNodeIn("PORT", this.getInputAt(i), input, pere);
        }
        ElementNode output = (ElementNode) pere.createElementEx("OUTPUT");
        for (int i = 0; i < this.getOutputLength(); i++) {
            addNodeIn("PORT", this.getOutputAt(i), output, pere);
        }
        mdl.appendChild(pere.createTextNode("\n\t\t"));
        mdl.appendChild(input);
        mdl.appendChild(pere.createTextNode("\n\t\t"));
        mdl.appendChild(output);
        mdl.appendChild(pere.createTextNode("\n\t\t"));
        addNodeIn("CHILD", "", mdl, pere);
        ElementNode eic = (ElementNode) pere.createElementEx("EIC");
        ElementNode eoc = (ElementNode) pere.createElementEx("EOC");
        ElementNode ic = (ElementNode) pere.createElementEx("IC");

        for (int i = 0; i < getLinkLength("IN"); i++) {
            ElementNode link = (ElementNode) pere.createElementEx("LINK");
            addNodeIn("PORT", getLinkSrcName("IN", i), link, pere);
            addNodeIn("PORT", getLinkDestName("IN", i), link, pere);
            eic.appendChild(link);
        }

        for (int i = 0; i < getLinkLength("OUT"); i++) {
            ElementNode link = (ElementNode) pere.createElementEx("LINK");
            addNodeIn("PORT", getLinkSrcName("OUT", i), link, pere);
            addNodeIn("PORT", getLinkDestName("OUT", i), link, pere);
            eoc.appendChild(link);
        }

        for (int i = 0; i < getLinkLength("INT"); i++) {
            ElementNode link = (ElementNode) pere.createElementEx("LINK");
            addNodeIn("PORT", getLinkSrcName("INT", i), link, pere);
            addNodeIn("PORT", getLinkDestName("INT", i), link, pere);
            ic.appendChild(link);
        }

        mdl.appendChild(pere.createTextNode("\n\t\t"));
        mdl.appendChild(eic);
        mdl.appendChild(pere.createTextNode("\n\t\t"));
        mdl.appendChild(eoc);
        mdl.appendChild(pere.createTextNode("\n\t\t"));
        mdl.appendChild(ic);
        father.appendChild(pere.createTextNode("\n\t\t"));
        father.appendChild(mdl);
        father.appendChild(pere.createTextNode("\n"));

        return (ElementNode) mdl.getElementsByTagName("CHILD").item(0);
    }

}
