/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelisator.data;

/**
 *
 * @author KACHER
 */

import java.awt.*;
import com.sun.xml.tree.*;
import java.util.*;

public class AtomicModelNode extends ModelNode {

    public AtomicModelNode() {
        super();
    }

    public AtomicModelNode(ElementNode e) {
        super(e);
    }

    public AtomicModelNode(String name, String type, Vector input, Vector output, Rectangle loc) {
        super(name, type, input, output, loc);
    }

    public ElementNode appendMeIn(XmlDocument pere, ElementNode father) {
        ElementNode mdl = (ElementNode) pere.createElementEx("MODEL");
        mdl.appendChild(pere.createTextNode("\n\t\t"));
        addNodeIn("TYPE", getType(), mdl, pere);
        mdl.appendChild(pere.createTextNode("\n\t\t"));
        addNodeIn("NAME", getName(), mdl, pere);
        mdl.appendChild(pere.createTextNode("\n\t\t"));
        ElementNode bounds = (ElementNode) pere.createElementEx("BOUNDS");
        addNodeIn("LOCX", new Integer(getX()).toString(), bounds, pere);
        addNodeIn("LOCY", new Integer(getY()).toString(), bounds, pere);
        addNodeIn("WIDTH", new Integer(getWidth()).toString(), bounds, pere);
        addNodeIn("HEIGHT", new Integer(getHeight()).toString(), bounds, pere);
        mdl.appendChild(bounds);
        ElementNode input = (ElementNode) pere.createElementEx("INPUT");
        for (int i = 0; i < this.getInputLength(); i++) {
            addNodeIn("PORT", this.getInputAt(i), input, pere);
        }
        ElementNode output = (ElementNode) pere.createElementEx("OUTPUT");
        for (int i = 0; i < this.getOutputLength(); i++) {
            addNodeIn("PORT", this.getOutputAt(i), output, pere);
        }
        mdl.appendChild(pere.createTextNode("\n\t\t"));
        mdl.appendChild(input);
        mdl.appendChild(pere.createTextNode("\n\t\t"));
        mdl.appendChild(output);
        mdl.appendChild(pere.createTextNode("\n\t\t"));
        father.appendChild(pere.createTextNode("\n\t\t"));
        father.appendChild(mdl);
        father.appendChild(pere.createTextNode("\n"));
        return null;
    }

}
