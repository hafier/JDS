/**
 * Title: Kit devel DEVS
 * Description: kit DEVS
 * Copyright:    Copyright (c) 2000
 * Company:Universite de corse
 * @author jbfilippi
 * @version 1.0
 */

package devsjava.modelisation.message;
import java.util.Vector;
import devsjava.*;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;


/**
 * Event Class, part of message
 */
public class Event {
/**
 * port of the event
 */
      private Port		port;
/**
 * action time of the event
 */
      private int		time;
 /**
  * content of the event
  */
      private Information	info;

 /**
 * empty constructor
 */
 public Event() {
    port = null;
    time = 0;
    info = null;
 }

  /**
  * Constructeur event (time ,String port and Information value)
  */
 public Event(int time, Port port, Information info){
    this.port = port;
    this.time = time;
    this.info = info;
  }
  /**
  * event Tomessage procedure creating a messsage determining the state of the event
  */

 public Message eventToMessage(Processor p, short type){
 Message msg;
 msg = new Message(p,time,port,type,info);
 return msg;
 }
public String toString(){
return "event de " + port.getName() + " - " + time + " info " + info;
}
}