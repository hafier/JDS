package devsjava.modelisation.message;
import java.util.Vector;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;
import devsjava.*;
/**
 * Title: Kit devel DEVS
 * Description: kit DEVS
 * Copyright:    Copyright (c) 2000
 * Company:Universite de corse
 * @author jbfilippi
 * @version 1.0
 */

public class Message {

   private  Processor   source;
   private   int               time;
   private   Port		port;
   private   short		type;//////////////////////////////////////////  private   String type;
   private   Information	info;

     public Message() {
     time = 0;
     port = null;
     type = 0;////////////////////////////////////////////////////////////////// type=null;
     source = null;
     info = null;
     }
     public Message(Processor source, int time, Port port, short type, Information info){/////public Message(Processor source, int time, Port port, String type, Information info){
     this.source = source;
     this.time = time;
     this.port = port;
     this.type = type;
     this.info = info;
     };

     public int getTime()   { return time;}
     public Port getPort() {return port;}
     public short getType(){return type;}////////////////////////////public String getType(){return type;}
     public Processor getSource() {return source;}
     public Information	getInfo() {return info;}
     public void setSource(Processor p){ this.source = p;};
     public void setPort(Port p){this.port = p;};
     public void setType(short s){this.type = s;};//////////////////////////////public void setType(String s){this.type = s;};
     public void setInfo(Information i){this.info = i;};

     public String toString(){
     //return (type + " Message de valeur " + info.getValue() + " de " + source  + " sur le port " + port.getName() + " pour le temps " + this.getTime() );
     if (type != 0 && info != null && port != null)// if (type != null && info != null && port != null)
      return ("[" + type + " " + info + " " + port.toString() + " t " + this.getTime() + "]");
     else return ("[---]");
     }

}