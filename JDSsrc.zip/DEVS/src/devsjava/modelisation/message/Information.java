/**
 * Title: Kit devel DEVS
 * Description: kit DEVS
 * Copyright:    Copyright (c) 2000
 * Company:Universite de corse
 * @author jbfilippi
 * @version 1.0
 */

package devsjava.modelisation.message;
import java.util.Vector;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;
import devsjava.*;
import java.util.*;
/**
 * Class centenant les infos passant
 */

public class Information {
     private double	value = 0.0;
     private String     text = null;
     public Information() {}
     public Information(double f) {  value = f;     }
     public Information(String text) {  this.text = text;     }
     public Information(double f, String text) { value = f;  this.text = text; }
     public Information(Information i) {
     value = i.getValue() ;
     text = i.getText();
     }

     public double getValue()   { return value;}
     public String getText()   { return text;}
     public void setValue(double f){value = f;}
     public void setText(String text) {  this.text = text;     }
    public String toString(){
      if (text != null)
      return value + " " + text ;///////////////////////////////////////////////return text + " " + value ;
      else
      return "" + value ;
      }
}