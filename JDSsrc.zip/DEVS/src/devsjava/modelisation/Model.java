package devsjava.modelisation;
import java.util.Vector;
import devsjava.*;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;

/**
 * Title: Kit devel DEVS
 * Description: kit DEVS
 * Copyright:    Copyright (c) 2000
 * Company:Universite de corse
 * @author jbfilippi
 * @version 1.0
 */

public abstract class Model extends devsjava.Entity  {
/**
 * classe de modele general
 */
     private Processor        process;
     private String	      child;
     private Model 	      parent;
     private Vector           input = new Vector();
     private Vector           output  = new Vector();

  public Model() {}

  public Model(String child, Model parent){
     this.parent = parent;
     this.child = child;
     
 }

  public void initPort(String s, Port port){
      if (s.compareTo("IN")==0)  input.add(port);
      if (s.compareTo("OUT")==0) output.add(port);
  }

    protected void setParent(Model m){this.parent = m;}
     public String	getChild()   {return child;}
     public void	setChild(String c)   {child = c;}
     public Model	getParent()   {return parent;}
     public Processor 	getProcess() {return process;}
     public String getPortName(String s, int i) {
      if (s.compareTo("IN") == 0)return (String)input.elementAt(i) ;
      if (s.compareTo("OUT") == 0) return (String)output.elementAt(i);
      return null;
     }

     public Port getPort(String s, int i) {
      if (s.compareTo("IN") == 0)return (Port)input.elementAt(i) ;
      if (s.compareTo("OUT") == 0) return (Port)output.elementAt(i);
      return null;
     }
    public Port getPortByName(String name){
    Port p = null;
     for (int i = 0 ; i < input.size() ; i++)
         if (((Port)input.elementAt(i)).getName().compareTo(name)  == 0)  p = (Port)input.elementAt(i);
     for (int i = 0 ; i < output.size() ; i++)
      if (((Port)output.elementAt(i)).getName().compareTo(name)  == 0)  p = (Port)output.elementAt(i);

    return p;
    }
     public void initProcess(Processor p){
      this.process = p;
     }
     public String	toString()   {return this.getName() ;}
     public void setInputs(Vector v){this.input = v;}
    public void setOutputs(Vector v){this.output = v;}
    public Vector getInputs(){return this.input ;}
    public Vector getOutputs(){return this.output ;}
    }