package devsjava.simulation.processor;

import java.util.Vector;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;
import devsjava.*;

/**
 * Title: Kit devel DEVS Description: kit DEVS Copyright: Copyright (c) 2000
 * Company:Universite de corse
 *
 * @author jbfilippi
 * @version 1.0bgfdhgfdhgf
 */

public class Coordinator extends devsjava.simulation.Processor {

    private ProcessorVector children = new ProcessorVector();
    private MessageVector ECH = new MessageVector();
    private MessageVector EV = new MessageVector();
    private CoupledModel cm = null;
    public static final short ev = 1;
    public static final short ech = 2;

    public Coordinator() {
    }

    public Coordinator(CoupledModel m, Processor p) {
        super(m, "coordinateur", p);
        cm = m; /////////////////////////////////+++
    }

    public void insert(short s, Message m) { /////////////////////////// !=

        if (m.getType() == STAR) {       
        }
        if (m.getType() == DONE) {
            m.setType(STAR);
        }
        if (m.getType() == X) {
            if ((m.getPort() != null) && (m.getPort().getOwner().equals(cm))) {
                cm.getReceiver(m);
            }
        }
        if (m.getType() == Y) {
            cm.getInfluencee(m);
            if (m.getSource() != this) {
                m.setType(X);
            }
        }

        if (s == ev) {
            EV.insertEV(m, cm.getChildren());
        } else {
            ECH.insertECH(m);
        }
/*
        
        if (m.getType().compareTo("*") == 0) {}
     if (m.getType().compareTo("done") == 0)  m.setType("*") ;
     if (m.getType().compareTo("x") == 0) {
         if ((m.getPort()  != null)&&(m.getPort().getOwner().equals(this.getModel())))
           ((CoupledModel)this.getModel()).getReceiver(m);
         }
     if (m.getType().compareTo("y") == 0) {
         ((CoupledModel)this.getModel()).getInfluencee(m);
         if (m.getSource() != this) m.setType("x");
         }

    if (s.compareTo("EV") == 0)    EV.insertEV(m,((CoupledModel)this.getModel()).getChildren() );
    else    ECH.insertECH(m);
        */
    }

    public MessageVector receivers(Message m) {

        MessageVector msg_lst;
        Message mess;

        if (this.getParent().getChild().compareTo("root") == 0) {
            while ((this.getTnext() < ECH.firstTime()) && EV.isNull()) {
                time = this.getTnext();  
                Processor p = null;
                try {
                    p = this.influences(time); //////////////////////////////// p = this.influences(this.getTnext());
                    if (p != null) {        ////////////////////////++ 
                        p.receivers(m);     ///////////////////////// ((Coordinator) p).receivers(m);
                    }
                } catch (Exception ex) {
                    System.out.println("Message null sur " + p);
                    ex.printStackTrace();
                    time = ECH.firstTime();
                    m = null;
                    break;
                }
                this.setTn();
            }
            if (EV.isNull()) {
                time = ECH.firstTime();
            }
            m = null;

        } else if (m.getType() == STAR) {///////////////////if (m.getType().compareTo("*") == 0)  
            if (m.getSource() != null) {
                this.insert(ev, m);///////////////////////////this.insert("EV",m);
            }
        } else {
            this.insert(ech, m);///////////////////////////////this.insert("ECH",m);
        }

        m = null;

        EV.translate(ECH, time, this.priorityList());

        if (EV.isNull()) {
            this.influences(this.getTnext()).receivers(m);///////////////////////((Coordinator)this.influences(this.getTnext())).receivers(m);
            this.setTn();
        } else {
            while (!EV.isNull()) {
                mess = EV.takeFirst();

                if (mess.getSource().getChild().compareTo("simulator") == 0) {
                    msg_lst = mess.getSource().receivers(mess);
                    for (; msg_lst.size() > 0;) {

                        mess = msg_lst.takeFirst();
                        if (mess.getTime() == time) {
                            insert(ev, mess);///////////////////////////insert("EV",mess);
                        } else {
                            insert(ech, mess);///////////////////////////////this.insert("ECH",mess);
                        }
                    }
                } else {
                    if (mess.getSource().equals(this)) {
                        if (this.getParent().getChild().compareTo("root") == 0) {
                            this.getParent().receivers(mess); /////////////////////// ((Root) this.getParent()).receivers(mess);
                        } else {
                            ((Coordinator) this.getParent()).insert(ev, mess);//////////////////////// ((Coordinator) this.getParent()).insert("EV",mess);
                        }
                    } else {
                        mess.getSource().receivers(mess);//((Coordinator) mess.getSource()).receivers(mess);
                    }
                }
            }
            this.setTn();

        }
        return null;
    }

    public Processor influences(int tmin) {
        int i;//////////////////////////////////////////////// int i,indexTime = -1;
        for (i = 0; i < children.size(); i++) {///////////////////////////for (i=0; indexTime == -1 ;i++)
            if (tmin == ((Processor) children.elementAt(i)).getTnext()) {////////////////indexTime = i; inside IF
                return (Processor) children.elementAt(i);                //////////////// return (Processor)children.elementAt(indexTime);       OUT IF last line
            }
        }
        return null;
    }

    public void setTn() {
        int tmin = Integer.MAX_VALUE;

        if (EV.isNull()) {
            for (int i = 0; i < children.size(); i++) {
                if (tmin > ((Processor) children.elementAt(i)).getTnext()) {
                    tmin = ((Processor) children.elementAt(i)).getTnext();
                }
            }
            if (tmin < ECH.firstTime()) {
                this.setTnext(tmin);
            } else {
                this.setTnext(ECH.firstTime());
            }
        } else {
            this.setTnext(EV.firstTime());
        }
    }

    public ProcessorVector getChildren() {
        return children;
    }

    public Vector priorityList() {
        return cm.getChildren();////////////////////return ((CoupledModel) getModel()).getChildren() ;
    }

    public MessageVector getEV() {
        return EV;
    }

    public MessageVector getECH() {
        return ECH;
    }

}
