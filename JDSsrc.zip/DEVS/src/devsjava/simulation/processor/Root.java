package devsjava.simulation.processor;
import java.util.Vector;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;
import devsjava.*;
import java.io.*;
/**
 * Title: Kit devel DEVS
 * Description: kit DEVS
 * Copyright:    Copyright (c) 2000
 * Company:Universite de corse
 * @author jbfilippi
 * @version 1.0
 */

public class Root extends devsjava.simulation.Processor{
       public static final int NOT_READY = 3;
    public static final int SIMULATING = 0;
    public static final int SIMULATION_READY = 1;
        public static final int SIMULATION_ENDED = 2;
     private Coordinator	children;
     private int		last_time;
     private Information	last_value;

     private int state = NOT_READY;
      PrintStream sortie = System.out ;

  public Root(Model m){
  super(null,"root",null);
   children = (Coordinator)m.getProcess();      ////////////////////// children = m.getProcess();
    m.getProcess().initParent(this);
    last_time = 1;
    last_value = null ;
    state = SIMULATION_READY;
  }

     public void init(){}

     public void simulation(){
     Coordinator co = children;

     while (co.getTnext()  < Integer.MAX_VALUE ){
      co.receivers(new Message(null,0,null,STAR,null));
     }
    }

     public void simulate(){
     state = SIMULATING;
     Coordinator co = children; ///////////////////////Coordinator co = (Coordinator)children;
     if (co.getTnext()  < Integer.MAX_VALUE )
    {
      co.receivers(new Message(null,0,null,STAR,null));//////////////////////// !=
    }
     else{
       state = SIMULATION_ENDED;
     }
     /*while (co.getTnext()  < Integer.MAX_VALUE ){
      co.receivers(new Message(null,0,null,"*",null));
     }*/
     }

     public MessageVector receivers(Message m){//////////////////////////////!=
        sortie.println(time + "\t" + m.getPort() + "\t" + m.getInfo()) ;
        m = null;
        return null;
   }
     /*
     public void receivers(Message m){
        sortie.println(time + "\t" + m.getPort() + "\t" + m.getInfo()) ;
        m = null;
   }
     */
  public void setSortie(PrintStream s){sortie = s;}
    public int getState(){return state;}
}