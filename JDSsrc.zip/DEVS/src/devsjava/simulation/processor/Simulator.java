package devsjava.simulation.processor;
import java.util.Vector;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;
import devsjava.*;

/**
 * Title: Kit devel DEVS
 * Description: kit DEVS
 * Copyright:    Copyright (c) 2000
 * Company:Universite de corse
 * @author jbfilippi
 * @version 1.0
 */

public class Simulator extends devsjava.simulation.Processor {
  private AtomicModel am = null;/////////////////////////////////// ++
   public Simulator(AtomicModel m, Processor p){//////////////////////////!=
      super(m,"simulator",p);
      am = m;
      this.setTlast(time);
      this.setTnext(Integer.MAX_VALUE );
  }
/* public Simulator(Model m, Processor p){
  super(m,"simulator",p);
  }*/
  public MessageVector receivers(Message m){/////////////////////////////////!=
   MessageVector	msg_lst = new MessageVector();
   EventVector   	ev_lst  = new EventVector();;
    if (m.getType()== STAR)
    {
    ev_lst = am.outFunction(m);
    msg_lst = ev_lst.EventVectorToMessageVector(this,Y);
    am.intTransition();
    }
    else
    {
        ev_lst = am.extTransition(m);
	msg_lst = ev_lst.EventVectorToMessageVector(this,DONE);
    }

    this.setTlast(time);
    if (am.advanceTime() != Integer.MAX_VALUE )
       this.setTnext( this.getTlast() +  am.advanceTime() ) ;
    else
        this.setTnext(Integer.MAX_VALUE );

    return msg_lst;
  }
/*
  public MessageVector receivers(Message m){
   MessageVector	msg_lst = new MessageVector();
   EventVector   	ev_lst  = new EventVector();;

    if (m.getType().compareTo("*") == 0)
    {
    ev_lst = ((AtomicModel)this.getModel()).outFunction(m);
    msg_lst = ev_lst.EventVectorToMessageVector(this,"y");
    ((AtomicModel)this.getModel()).intTransition();
    }
    else
    {
        ev_lst = ((AtomicModel)this.getModel()).extTransition(m);
	msg_lst = ev_lst.EventVectorToMessageVector(this,"done");
    }

    this.setTlast(time);
    if (((AtomicModel)this.getModel()).advanceTime() != Integer.MAX_VALUE )
       this.setTnext( this.getTlast() +  ((AtomicModel)this.getModel()).advanceTime() ) ;
    else
        this.setTnext(Integer.MAX_VALUE );


    return msg_lst;
  }
  */

}