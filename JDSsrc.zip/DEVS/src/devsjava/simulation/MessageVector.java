package devsjava.simulation;

import java.util.Vector;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;
import devsjava.*;

/**
 * Title: Kit devel DEVS Description: kit DEVS Copyright: Copyright (c) 2000
 * Company:Universite de corse
 *
 * @author jbfilippi
 * @version 1.0
 */
public class MessageVector extends Vector {

    public MessageVector() {
        super(100);//////////////////////                       ++
    }

    public void insertECH(Message m) {
        /**
         * Insere l'element trie dans l'echeancier
         */
        Message ms = null;
        boolean cont = true, trouve = false;
        int i = 0;
        while (cont && !trouve) {
            if (this.size() > i) {
                ms = ((Message) this.elementAt(i));
            } else {
                ms = null;
            }
            if ((ms == null) || (ms.getTime() > m.getTime())) {
                cont = false;
            } else if (ms.getTime() == m.getTime()) {
                if (ms.getSource() == m.getSource()) {
                    if (ms.getPort().equals(m.getPort())) {
                        trouve = true;
                    }
                }
            }
            if (!trouve && cont) {
                i++;
            }
        }
        if (trouve) {
            ms = m;
            m = null;
        } else {
            this.insertElementAt(m, i);
        }
        // System.out.println("ECH de " + m.getSource() + " Temps " + m.getSource().time +" " + this) ;
    }

    public void insertEV(Message m, Vector priority) {
        /**
         * insert trie dens l'echeancier des messages a traiter au temps courant
         * selon l'ordre de priorite
         */

        Message ms = null;
        boolean cont = true, trouve = false; //cont = si on a pas depasse le temps, trouve = si c'est le meme message avec une nouvelle sortie
        Model mo = m.getSource().getModel();//
        int i = 0;

        while (cont && !trouve) {
            ms = null;
            if (this.size() > i) {
                ms = ((Message) this.elementAt(i));
            }
            if ((ms == null) || (priority.indexOf(ms.getSource().getModel()) > priority.indexOf(mo))) {
                cont = false;
            } else if (ms.getPort().equals(m.getPort())) {
                if (m.getSource().equals(ms.getSource())) {
                    if (ms.getType() == m.getType()) {
                        trouve = true;
                    } else if (ms.getType() == Processor.STAR) {///////////////if (ms.getType().compareTo("*") == 0) 
                        cont = false;
                    }
                }
            }
            if (!trouve && cont) {
                i++;
            }
        }

        if (trouve) {
            ms = m;
            m = null;
        } else {
            this.insertElementAt(m, i);
        }

    }

    public void translate(MessageVector ev, int tp, Vector priority) {
        Message temp;

        while ((ev.size() > 0) && (ev.firstTime() == tp)) {
            temp = ev.takeFirst();
            this.insertEV(temp, priority);
        }
    }

    public int firstTime() {

        if (this.size() == 0) {
            return Integer.MAX_VALUE;
        } else {
            return ((Message) this.firstElement()).getTime();
        }
    }

    public Message takeFirst() {
        if (this.size() > 0) {
            if (this.firstElement() != null) {
                return (Message) this.remove(0);
            }
        }

        return null;
    }

    public boolean isNull() {
        return this.isEmpty();
    }

    public String toString() {
        String temp = new String();
        for (int i = 0; i < this.size(); i++) {
            temp = temp + "[" + ((Message) this.elementAt(i)).getType() + ((Message) this.elementAt(i)).getTime() + " " + ((Message) this.elementAt(i)).getPort().toString() + " " + ((Message) this.elementAt(i)).getInfo().getValue() + "]";
        }
        return temp;
    }
}
