package devsjava.simulation;
import java.util.Vector;
import devsjava.simulation.*;
import devsjava.simulation.processor.*;
import devsjava.modelisation.*;
import devsjava.modelisation.message.*;
import devsjava.modelisation.model.*;
import devsjava.*;

/**
 * Title: Kit devel DEVS
 * Description: kit DEVS
 * Copyright:    Copyright (c) 2000
 * Company:Universite de corse
 * @author jbfilippi
 * @version 1.0
 */

public class EventVector extends Vector {

      public EventVector (){
      super(100);
      }


    public MessageVector EventVectorToMessageVector(Processor po, short type)
    {
         MessageVector msgV = new MessageVector();
        for (int i = 0; i < this.size() ;i++)
             msgV.insertECH(((Event)this.elementAt(i)).eventToMessage(po,type)) ;
        return msgV;
    }

    public void insertFirst(Event ev){this.insertElementAt(ev,0);}

}